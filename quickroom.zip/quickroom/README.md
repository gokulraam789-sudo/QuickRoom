# QuickRoom — Share Anything. Leave Nothing Behind.

Temporary, account-free file / text / code sharing between devices. Make a room, share the Room ID + password,
transfer things, and everything is locked and deleted when the timer (max **30 minutes**) ends.

**Stack:** React + Vite + Tailwind + Framer Motion + Lucide · Node + Express + Multer + Socket.IO + bcrypt + Helmet.
**No database.** Room metadata is in memory; files are temporary files on the server's disk.

---

## 1. Run it in GitHub Codespaces (quick start)

```bash
# in the Codespace terminal (upload quickroom.zip to the Codespace first: drag it into the Explorer)
unzip quickroom.zip
cd quickroom
npm run install:all          # installs root, backend and frontend dependencies
cp -n backend/.env.example backend/.env
npm run dev                  # starts API (4000) + website (5173) together
```

Codespaces will show a notification for port **5173** — click *Open in Browser*.
You only need port 5173: the Vite dev server forwards `/api` and `/socket.io` to the backend internally, so there is no CORS setup.

**Test from your phone:** in the *Ports* tab, right-click port 5173 → *Port Visibility → Public*, then open that URL on your phone.
Create a room on the laptop, join it from the phone.

| Command | What it does |
|---|---|
| `npm run dev` | API + website with auto-reload |
| `npm test` | Backend automated tests (16 tests) |
| `npm run build` | Production build of the frontend (`frontend/dist`) |
| `npm --prefix backend start` | Run only the API |

---

## 2. How it works

```
Browser ──HTTP (Bearer token)──▶ Express ─▶ roomService (in-memory rooms, sessions, expiry)
   ▲                               │               │
   └────── Socket.IO events ◀──────┘               └─▶ storageService (temp/ folder on disk)
                                         cleanupJob: every 5 s expire rooms, retry deletes, sweep orphans
```

1. `POST /api/rooms` → server creates a 60-bit random Room ID, bcrypt-hashes the password, sets `expiresAt` (never > 30 min) and returns a short-lived **session token**.
2. Joining (`POST /api/rooms/join`) checks ID, password and expiry, then issues a token. Wrong passwords lock out after 5 tries (per IP + room) on top of IP rate limits.
3. Every other request carries `Authorization: Bearer <token>`. The server finds the room **from the token** (the client can't name a room) and re-checks expiry on **every** call.
4. Files go up by HTTP (`multipart`), are validated, stored under a random name in `backend/temp/rooms/<roomId>/`, and are only served through authorized endpoints. The browser downloads/previews them with `fetch` + the token, so there is **no public file URL**.
5. Socket.IO only carries small events (`file:added`, `note:added`, `participants`, `room:expired`…). A socket can't join a room without a valid token.
6. On expiry the server **synchronously** marks the room dead and kills its sessions, *then* deletes the folder, verifies it is gone, drops the metadata and notifies sockets with `cleanupConfirmed: true/false`. If deletion fails the room stays inaccessible and the sweep retries every 5 s. The "Room Expired" page only says files were deleted when `cleanupConfirmed` is true.

### Folder structure
```
quickroom/
├─ backend/
│  ├─ src/ routes/ controllers/ middleware/ services/ sockets/ jobs/ utils/ app.js server.js
│  ├─ tests/api.test.js     # auth, expiry, uploads, downloads, cleanup, sockets
│  ├─ temp/                 # temporary uploads (wiped on start; git-ignored)
│  └─ .env.example
├─ frontend/
│  ├─ src/ components/ pages/ hooks/ services/ utils/ App.jsx main.jsx
│  └─ .env.example
└─ README.md
```

### Configuration (`backend/.env`)
`PORT`, `CLIENT_ORIGINS` (CORS allow-list), `TRUST_PROXY`, `TEMP_DIR`, `MAX_FILE_MB` (25), `ROOM_STORAGE_MB` (100),
`MAX_FILES_PER_ROOM` (30), `MAX_ACTIVE_ROOMS`, `MAX_PASSWORD_ATTEMPTS`, `LOCKOUT_SECONDS`, `BCRYPT_ROUNDS`, `SWEEP_INTERVAL_MS`.
The 30-minute ceiling is hard-coded in `config.js` on purpose.

---

## 3. Security summary

| Requirement | Implementation |
|---|---|
| Unpredictable IDs / passwords | `crypto.randomInt` for Room IDs; browser `crypto.getRandomValues` (rejection sampling) for generated passwords; 256-bit session tokens |
| Password storage | bcrypt hash only; never logged or returned |
| Authorization everywhere | `requireRoom` middleware on every protected route + socket handshake check |
| Server-enforced expiry | `requireActive()` on each call + per-room timer + 5 s sweep; the client timer is display-only |
| Rate limiting | create / join / upload / global limiters + per-IP-per-room password lockout |
| Uploads | extension allow-list, magic-byte check, size / count / room-storage / concurrency limits, random on-disk names, `path.basename` + id regexes against traversal |
| No execution | downloads are `application/octet-stream`; previews are `text/plain` / fixed image / PDF types with `nosniff` and `CSP: sandbox`; text is rendered as React text nodes; highlighted code is escaped by highlight.js; code is never run |
| Headers / CORS | Helmet; CORS limited to `CLIENT_ORIGINS` |
| Secrets in URLs | none — password only in POST bodies, token only in a header |
| Errors | friendly JSON; internals only in server logs |

### Honest limitations
* **Not end-to-end encrypted.** Files are readable by the server while the room lives. Use HTTPS in production (Codespaces and most hosts provide it).
* **In-memory metadata:** restarting the server drops all rooms. Files left on disk are wiped at startup, so nothing outlives a restart.
* **Single instance only.** Rooms, sessions and sockets live in one process. Several instances need shared metadata (e.g. Redis), shared temp object storage and the Socket.IO Redis adapter.
* **Hosting:** serverless platforms (Vercel/Netlify functions) can't host this backend (no long-lived WebSockets or durable temp disk). Use a long-running Node host. "Deleted" means removed from the app's filesystem; host-level snapshots/backups are outside the app's control.
* The creator's password is kept in browser **memory** only (for the Invite button) and is gone after a refresh; the session token survives a refresh via `sessionStorage` for that tab.
* A participant ID is created per join, so "delete your own uploads" applies to that session; re-joining creates a new identity.
* Downloads/previews are loaded fully into browser memory (≤ 25 MB by default).

---

## 4. Testing checklist

**Automated:** `npm test` covers creation limits, bcrypt, join / wrong-password / lockout, token-gated access, upload / preview / download, cross-room access, HTML served as text, type / magic-byte / size / traversal checks, owner-only deletes, text & code validation, **expired room rejects every operation**, physical deletion, orphan + stale-upload sweep, startup wipe, **failed-deletion retry**, and socket auth / events / expiry notice.

**Manual** (two browsers, or laptop + phone):
1. **Create** a room (try 1 min): ID + password shown, copy buttons work, *Enter Room*.
2. **Join** from another browser/device: participant count becomes 2.
3. **Wrong password** → "Incorrect Room ID or password."; 5 wrong tries → "Too many incorrect attempts…". Random ID → "couldn't find that room".
4. **Upload** several files (drag-drop + Browse): progress bars; the other device sees them instantly. **Download** works and content matches.
5. **Preview** a PNG, a PDF, a `.py`/`.json` file; `.docx` offers download only.
6. **Text & code**: share on one device, it appears on the other without refresh; copy buttons work; paste `<script>alert(1)</script>` → shown literally.
7. **Delete** your own file/text → disappears everywhere; you can't delete others' items.
8. **Countdown** matches on both devices and survives refresh; amber < 1 min, red < 10 s.
9. **Expiry**: let a 1-minute room end → both devices show *Room Expired*; the old ID + password says expired.
10. **Physical deletion**: before expiry `ls backend/temp/rooms` shows the room folder; after expiry it's empty.
11. **Restart cleanup**: stop the backend (Ctrl+C), run `mkdir -p backend/temp/rooms/ABCDEFGHJKLM && touch backend/temp/rooms/ABCDEFGHJKLM/x`, start again → log reports leftovers removed and the folder is gone.
12. **Unauthorized download**: `curl -i http://localhost:4000/api/rooms/files/<id>/download` → 401; a token from a different room → 404.
13. **Limits**: upload a `.exe` (rejected), a text file renamed `.png` (rejected), a file > 25 MB (rejected before upload).
14. **Mobile**: open on a phone; tabs, upload and the credentials modal fit the screen; the Share button appears on phones that support it.
15. **Network drop**: airplane mode for a few seconds → header shows "Reconnecting…", then resyncs with no duplicates.

---

## 5. Deployment guidance

The app needs **one long-running Node server** (WebSockets + temp disk) plus a static host for the frontend (or serve both from one place).

1. **Backend** on Render / Railway / Fly.io / a VPS: build `npm --prefix backend install`, start `npm --prefix backend start`. Set `TRUST_PROXY=1`, `CLIENT_ORIGINS=https://your-frontend-domain`, optionally `TEMP_DIR=/tmp/quickroom`. Health check: `/api/health`. Keep **one instance**.
2. **Frontend**: `VITE_API_URL=https://your-api-domain npm --prefix frontend run build`, then host `frontend/dist` on Netlify / Vercel / Cloudflare Pages.
3. HTTPS only.

**Scaling later:** rooms/sessions in Redis (with TTL), uploads in object storage (S3/R2/GCS, with a ≤1-day lifecycle rule as a safety net) and `@socket.io/redis-adapter`.
Only `services/roomService.js` and `services/storageService.js` need to change — routes and controllers stay the same.
