// Run with: npm test   (uses Node's built-in test runner, no extra framework)
import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import http from 'node:http';

const tmp = await fs.mkdtemp(path.join(os.tmpdir(), 'quickroom-test-'));
process.env.TEMP_DIR = tmp; // tests never touch the real temp folder
process.env.BCRYPT_ROUNDS = '4';

const { config } = await import('../src/config.js');
const { createApp } = await import('../src/app.js');
const { attachSockets } = await import('../src/sockets/index.js');
const roomService = await import('../src/services/roomService.js');
const storage = await import('../src/services/storageService.js');
const { io: connect } = await import('socket.io-client');

let server, io, base;
const call = async (url, { method = 'GET', token, body, form } = {}) => {
  const headers = {};
  if (token) headers.Authorization = `Bearer ${token}`;
  if (body) headers['Content-Type'] = 'application/json';
  const res = await fetch(base + url, { method, headers, body: body ? JSON.stringify(body) : form });
  const type = res.headers.get('content-type') || '';
  return { status: res.status, headers: res.headers, data: type.includes('json') ? await res.json() : await res.text() };
};
const makeRoom = async (password = 'secret123', durationMinutes = 10) => (await call('/api/rooms', { method: 'POST', body: { durationMinutes, password } })).data;
const joinRoom = (roomId, password) => call('/api/rooms/join', { method: 'POST', body: { roomId, password } });
const upload = (token, name, content) => {
  const form = new FormData();
  form.append('file', new Blob([content]), name);
  return call('/api/rooms/files', { method: 'POST', token, form });
};
const roomDir = (id) => path.join(tmp, 'rooms', id);
const exists = (p) => fs.access(p).then(() => true, () => false);

before(async () => {
  await storage.init();
  server = http.createServer(createApp());
  io = attachSockets(server);
  await new Promise((r) => server.listen(0, r));
  base = `http://localhost:${server.address().port}`;
});
after(async () => {
  io.close();
  await new Promise((r) => server.close(r));
  await fs.rm(tmp, { recursive: true, force: true });
});

test('creating a room returns an unguessable id, a token and a server-set expiry', async () => {
  const before = Date.now();
  const r = await call('/api/rooms', { method: 'POST', body: { durationMinutes: 30, password: 'secret123' } });
  assert.equal(r.status, 201);
  assert.match(r.data.roomId, /^[A-HJ-NP-Z2-9]{12}$/);
  assert.ok(r.data.token.length >= 40);
  assert.ok(r.data.expiresAt - before <= 30 * 60_000 + 2000);
  assert.equal(JSON.stringify(r.data).includes('secret123'), false);
});

test('duration can never exceed 30 minutes or be invalid; weak passwords are rejected', async () => {
  assert.equal((await call('/api/rooms', { method: 'POST', body: { durationMinutes: 31, password: 'secret123' } })).status, 400);
  assert.equal((await call('/api/rooms', { method: 'POST', body: { durationMinutes: 0, password: 'secret123' } })).status, 400);
  assert.equal((await call('/api/rooms', { method: 'POST', body: { durationMinutes: 5, password: '123' } })).status, 400);
});

test('password is stored only as a bcrypt hash', async () => {
  const { roomId } = await makeRoom('hunter2-hunter2');
  const room = roomService.peek(roomId);
  assert.match(room.passwordHash, /^\$2[aby]\$/);
  assert.equal(JSON.stringify(room.passwordHash).includes('hunter2'), false);
});

test('joining: correct, wrong password, unknown room, dashes/lowercase accepted', async () => {
  const { roomId } = await makeRoom('secret123');
  assert.equal((await joinRoom(roomId, 'secret123')).status, 200);
  const pretty = roomId.toLowerCase().match(/.{4}/g).join('-');
  assert.equal((await joinRoom(pretty, 'secret123')).status, 200);
  const bad = await joinRoom(roomId, 'nope-nope');
  assert.equal(bad.status, 401);
  assert.equal(bad.data.error.code, 'INVALID_CREDENTIALS');
  assert.equal((await joinRoom('ABCDEFGHJKLM', 'secret123')).status, 404);
});

test('repeated wrong passwords lock the attempt out (429)', async () => {
  const { roomId } = await makeRoom('secret123');
  for (let i = 0; i < config.maxPasswordAttempts; i++) assert.equal((await joinRoom(roomId, 'wrong-pass')).status, 401);
  const locked = await joinRoom(roomId, 'secret123'); // even the right password is refused while locked
  assert.equal(locked.status, 429);
  assert.equal(locked.data.error.code, 'TOO_MANY_ATTEMPTS');
});

test('protected endpoints require a valid token', async () => {
  assert.equal((await call('/api/rooms/state')).status, 401);
  assert.equal((await call('/api/rooms/state', { token: 'garbage' })).status, 401);
  assert.equal((await call('/api/rooms/notes', { method: 'POST', body: { kind: 'text', content: 'x' } })).status, 401);
});

test('upload, list, preview and download a file; other rooms and anonymous users cannot', async () => {
  const a = await makeRoom();
  const b = await makeRoom();
  const up = await upload(a.token, 'notes.txt', 'hello quickroom');
  assert.equal(up.status, 201);
  const id = up.data.file.id;

  const state = await call('/api/rooms/state', { token: a.token });
  assert.equal(state.data.files.length, 1);

  const dl = await call(`/api/rooms/files/${id}/download`, { token: a.token });
  assert.equal(dl.status, 200);
  assert.equal(dl.data, 'hello quickroom');
  assert.match(dl.headers.get('content-disposition'), /attachment/);
  assert.equal(dl.headers.get('content-type'), 'application/octet-stream');

  const pv = await call(`/api/rooms/files/${id}/preview`, { token: a.token });
  assert.equal(pv.status, 200);
  assert.match(pv.headers.get('content-type'), /^text\/plain/);

  assert.equal((await call(`/api/rooms/files/${id}/download`)).status, 401);
  assert.equal((await call(`/api/rooms/files/${id}/download`, { token: b.token })).status, 404);
  assert.equal((await call(`/api/rooms/files/${id}/preview`, { token: b.token })).status, 404);

  // stored under a random name, not the user's filename
  const onDisk = await fs.readdir(roomDir(a.roomId));
  assert.deepEqual(onDisk, [id]);
});

test('uploaded HTML is served as plain text, never as HTML', async () => {
  const a = await makeRoom();
  const up = await upload(a.token, 'evil.html', '<script>alert(1)</script>');
  assert.equal(up.status, 201);
  const pv = await call(`/api/rooms/files/${up.data.file.id}/preview`, { token: a.token });
  assert.match(pv.headers.get('content-type'), /^text\/plain/);
  assert.equal(pv.headers.get('x-content-type-options'), 'nosniff');
});

test('unsupported types, fake images, oversize files and path-traversal names are handled', async () => {
  const a = await makeRoom();
  assert.equal((await upload(a.token, 'run.exe', 'MZ....')).status, 415);
  assert.equal((await upload(a.token, 'fake.png', 'this is not a png')).status, 415);
  const sane = await upload(a.token, '../../etc/passwd.txt', 'x');
  assert.equal(sane.status, 201);
  assert.equal(sane.data.file.name, 'passwd.txt');

  const old = config.maxFileBytes;
  config.maxFileBytes = 1024;
  try { assert.equal((await upload(a.token, 'big.txt', 'a'.repeat(200_000))).status, 413); } finally { config.maxFileBytes = old; }
  const incoming = await fs.readdir(path.join(tmp, 'incoming'));
  assert.deepEqual(incoming, [], 'rejected uploads must not leave temp files behind');
});

test('only the uploader can delete a file; deletion removes it from disk', async () => {
  const a = await makeRoom();
  const other = (await joinRoom(a.roomId, 'secret123')).data;
  const up = await upload(a.token, 'mine.txt', 'data');
  const id = up.data.file.id;
  assert.equal((await call(`/api/rooms/files/${id}`, { method: 'DELETE', token: other.token })).status, 403);
  assert.equal((await call(`/api/rooms/files/${id}`, { method: 'DELETE', token: a.token })).status, 200);
  assert.deepEqual(await fs.readdir(roomDir(a.roomId)), []);
  assert.equal((await call(`/api/rooms/files/${id}/download`, { token: a.token })).status, 404);
});

test('text and code sharing: stored verbatim as data, validated, owner-only delete', async () => {
  const a = await makeRoom();
  const other = (await joinRoom(a.roomId, 'secret123')).data;
  const xss = '<img src=x onerror=alert(1)>';
  const t = await call('/api/rooms/notes', { method: 'POST', token: a.token, body: { kind: 'text', content: xss } });
  assert.equal(t.status, 201);
  assert.equal(t.data.note.content, xss);
  const c = await call('/api/rooms/notes', { method: 'POST', token: a.token, body: { kind: 'code', content: 'print(1)', language: 'python' } });
  assert.equal(c.data.note.language, 'python');
  const weird = await call('/api/rooms/notes', { method: 'POST', token: a.token, body: { kind: 'code', content: 'x', language: 'bash; rm -rf' } });
  assert.equal(weird.data.note.language, 'plaintext');
  assert.equal((await call('/api/rooms/notes', { method: 'POST', token: a.token, body: { kind: 'text', content: '   ' } })).status, 400);
  assert.equal((await call('/api/rooms/notes', { method: 'POST', token: a.token, body: { kind: 'text', content: 'a'.repeat(config.maxTextChars + 1) } })).status, 413);
  assert.equal((await call(`/api/rooms/notes/${t.data.note.id}`, { method: 'DELETE', token: other.token })).status, 403);
  assert.equal((await call(`/api/rooms/notes/${t.data.note.id}`, { method: 'DELETE', token: a.token })).status, 200);
  const state = await call('/api/rooms/state', { token: other.token });
  assert.equal(state.data.notes.length, 2);
});

test('expired room rejects EVERY protected operation and its files are physically deleted', async () => {
  const a = await makeRoom('secret123');
  const up = await upload(a.token, 'secret.txt', 'top secret');
  const fileId = up.data.file.id;
  assert.equal(await exists(roomDir(a.roomId)), true);

  const room = roomService.peek(a.roomId);
  room.expiresAt = Date.now() - 1; // simulate the clock running out
  // First protected call after expiry notices it. No cron needed:
  const state = await call('/api/rooms/state', { token: a.token });
  assert.equal(state.status, 410);
  await roomService.expireRoom(room);

  assert.equal((await call('/api/rooms/state', { token: a.token })).status, 410);
  assert.equal((await call(`/api/rooms/files/${fileId}/download`, { token: a.token })).status, 410);
  assert.equal((await call(`/api/rooms/files/${fileId}/preview`, { token: a.token })).status, 410);
  assert.equal((await upload(a.token, 'late.txt', 'x')).status, 410);
  assert.equal((await call('/api/rooms/notes', { method: 'POST', token: a.token, body: { kind: 'text', content: 'x' } })).status, 410);
  const rejoin = await joinRoom(a.roomId, 'secret123'); // the old credentials cannot restore access
  assert.equal(rejoin.status, 410);
  assert.equal(rejoin.data.error.code, 'ROOM_EXPIRED');

  assert.equal(await exists(roomDir(a.roomId)), false, 'room directory must be gone');
  assert.equal(roomService.peek(a.roomId), undefined, 'room metadata must be gone');
  assert.equal(rejoin.data.error.cleanupConfirmed, true);
});

test('periodic sweep expires rooms without any request and removes orphaned files', async () => {
  const a = await makeRoom();
  await upload(a.token, 'x.txt', 'x');
  roomService.peek(a.roomId).expiresAt = Date.now() - 1;
  const orphan = path.join(tmp, 'rooms', 'ZZZZZZZZZZZZ'.replace(/Z/g, 'K'));
  await fs.mkdir(orphan, { recursive: true });
  await fs.writeFile(path.join(orphan, 'a1b2c3d4e5f6a1b2c3d4e5f6'), 'left behind');
  const stale = path.join(tmp, 'incoming', 'stale-upload');
  await fs.writeFile(stale, 'partial');
  await fs.utimes(stale, new Date(0), new Date(0));

  await roomService.sweep();

  assert.equal(await exists(roomDir(a.roomId)), false);
  assert.equal(await exists(orphan), false);
  assert.equal(await exists(stale), false);
});

test('startup cleanup wipes everything left from a previous run', async () => {
  const ghost = path.join(tmp, 'rooms', 'GHOSTGHOSTGH');
  await fs.mkdir(ghost, { recursive: true });
  await fs.writeFile(path.join(ghost, 'f'), 'x');
  await fs.writeFile(path.join(tmp, 'incoming', 'half-upload'), 'x');
  const removed = await storage.wipeAll();
  assert.ok(removed >= 2);
  assert.deepEqual(await fs.readdir(path.join(tmp, 'rooms')), []);
  assert.deepEqual(await fs.readdir(path.join(tmp, 'incoming')), []);
});

test('failed deletion keeps the room inaccessible and is retried by the sweep', async () => {
  const a = await makeRoom();
  await upload(a.token, 'x.txt', 'x');
  const room = roomService.peek(a.roomId);
  const original = fs.rm;
  let failures = 1;
  fs.rm = async (...args) => { if (failures-- > 0) throw new Error('disk busy'); return original(...args); };
  try {
    room.expiresAt = Date.now() - 1;
    await roomService.expireRoom(room);
    assert.equal(room.cleanupPending, true);
    const r = await call('/api/rooms/state', { token: a.token });
    assert.equal(r.status, 410);
    assert.equal(r.data.error.cleanupConfirmed, false); // we do not claim deletion yet
    assert.equal((await joinRoom(a.roomId, 'secret123')).status, 410);
  } finally { fs.rm = original; }
  await roomService.sweep();
  assert.equal(await exists(roomDir(a.roomId)), false);
  assert.equal(roomService.peek(a.roomId), undefined);
});

test('sockets: need a valid token, get live events, participant count and expiry notice', async () => {
  const a = await makeRoom();
  const other = (await joinRoom(a.roomId, 'secret123')).data;

  const denied = connect(base, { auth: { token: 'nope' }, reconnection: false, transports: ['websocket'] });
  const deniedErr = await new Promise((res) => denied.on('connect_error', res));
  assert.equal(deniedErr.message, 'UNAUTHORIZED');
  denied.close();

  const s1 = connect(base, { auth: { token: a.token }, reconnection: false, transports: ['websocket'] });
  const events = [];
  for (const ev of ['participants', 'note:added', 'file:added', 'room:expired']) s1.on(ev, (p) => events.push([ev, p]));
  await new Promise((r) => s1.on('connect', r));
  const s2 = connect(base, { auth: { token: other.token }, reconnection: false, transports: ['websocket'] });
  await new Promise((r) => s2.on('connect', r));

  await call('/api/rooms/notes', { method: 'POST', token: other.token, body: { kind: 'text', content: 'hi from phone' } });
  await upload(other.token, 'pic.txt', 'x');
  await new Promise((r) => setTimeout(r, 200));
  assert.ok(events.some(([e, p]) => e === 'participants' && p.count === 2));
  assert.ok(events.some(([e, p]) => e === 'note:added' && p.note.content === 'hi from phone'));
  assert.ok(events.some(([e]) => e === 'file:added'));

  roomService.peek(a.roomId).expiresAt = Date.now() - 1;
  await roomService.expireRoom(roomService.peek(a.roomId));
  await new Promise((r) => setTimeout(r, 200));
  assert.ok(events.some(([e, p]) => e === 'room:expired' && p.cleanupConfirmed === true));
  assert.equal(s1.connected, false);
  s1.close(); s2.close();
});
