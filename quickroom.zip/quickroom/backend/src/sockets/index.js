import { Server } from 'socket.io';
import { config } from '../config.js';
import * as roomService from '../services/roomService.js';
import * as realtime from './realtime.js';

export function attachSockets(httpServer) {
  const io = new Server(httpServer, { cors: { origin: config.clientOrigins }, maxHttpBufferSize: 10_000 });
  realtime.setIO(io);

  // Nobody gets into a room channel without a valid, unexpired session token. A client-supplied room id is ignored.
  io.use((socket, next) => {
    try {
      const token = socket.handshake.auth?.token;
      const { room, session } = roomService.authenticate(token);
      socket.data = { roomId: room.id, participantId: session.participantId, token };
      next();
    } catch (err) {
      next(new Error(err.code || 'UNAUTHORIZED'));
    }
  });

  io.on('connection', (socket) => {
    const { roomId, participantId } = socket.data;
    socket.join(realtime.channel(roomId));
    io.to(realtime.channel(roomId)).emit('participants', { count: realtime.addPresence(roomId, participantId) });
    socket.on('disconnect', () => {
      const count = realtime.removePresence(roomId, participantId);
      io.to(realtime.channel(roomId)).emit('participants', { count });
    });
  });
  return io;
}
