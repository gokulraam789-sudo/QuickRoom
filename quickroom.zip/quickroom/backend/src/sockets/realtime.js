// Tiny holder for the Socket.IO server so services/controllers can broadcast without importing socket setup.
let io = null;
const presence = new Map(); // roomId -> Map(participantId -> open socket count)

export const setIO = (server) => { io = server; };
export const channel = (roomId) => `room:${roomId}`;
export const emitToRoom = (roomId, event, payload) => io?.to(channel(roomId)).emit(event, payload);
export const participantCount = (roomId) => presence.get(roomId)?.size ?? 0;

export function addPresence(roomId, participantId) {
  const m = presence.get(roomId) ?? new Map();
  m.set(participantId, (m.get(participantId) ?? 0) + 1);
  presence.set(roomId, m);
  return m.size;
}
export function removePresence(roomId, participantId) {
  const m = presence.get(roomId);
  if (!m) return 0;
  const left = (m.get(participantId) ?? 1) - 1;
  if (left <= 0) m.delete(participantId); else m.set(participantId, left);
  if (m.size === 0) presence.delete(roomId);
  return m.size;
}

export function notifyExpired(roomId, payload) {
  if (!io) return;
  io.to(channel(roomId)).emit('room:expired', payload);
  io.in(channel(roomId)).disconnectSockets(true);
  presence.delete(roomId);
}
export function disconnectToken(token) {
  if (!io) return;
  for (const s of io.sockets.sockets.values()) if (s.data.token === token) s.disconnect(true);
}
