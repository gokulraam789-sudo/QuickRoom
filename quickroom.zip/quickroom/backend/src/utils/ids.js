import crypto from 'node:crypto';

// No 0/O/1/I so IDs are easy to read out loud or type on a phone. 32 symbols x 12 chars = 60 bits.
const ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';

export const randomString = (len) => {
  let out = '';
  for (let i = 0; i < len; i++) out += ALPHABET[crypto.randomInt(ALPHABET.length)];
  return out;
};
export const newRoomId = () => randomString(12);
export const normalizeRoomId = (v) => String(v ?? '').toUpperCase().replace(/[^A-Z0-9]/g, '');
export const isValidRoomId = (v) => /^[A-HJ-NP-Z2-9]{12}$/.test(v);
export const newToken = () => crypto.randomBytes(32).toString('base64url'); // session secret
export const newId = () => crypto.randomBytes(12).toString('hex'); // 24 hex chars
