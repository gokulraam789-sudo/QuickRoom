import fs from 'node:fs/promises';
import path from 'node:path';

const text = { kind: 'text', mime: 'text/plain' };
// Allow-list. Text-like files are always *served* as text/plain, so uploaded HTML/JS can never run in our origin.
export const FILE_TYPES = {
  png: { kind: 'image', mime: 'image/png' },
  jpg: { kind: 'image', mime: 'image/jpeg' },
  jpeg: { kind: 'image', mime: 'image/jpeg' },
  webp: { kind: 'image', mime: 'image/webp' },
  pdf: { kind: 'pdf', mime: 'application/pdf' },
  doc: { kind: 'binary', mime: 'application/msword' },
  docx: { kind: 'binary', mime: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' },
  txt: text, md: text, csv: text, json: text, sql: text,
  py: text, js: text, jsx: text, ts: text, tsx: text,
  html: text, css: text, java: text, c: text, cpp: text, h: text,
};

export const extOf = (name) => path.extname(name).slice(1).toLowerCase();

export function sanitizeFilename(original) {
  let name = String(original ?? '');
  // busboy hands us latin1; browsers send UTF-8 bytes. Re-decode unless it is clearly already Unicode.
  if (!/[^\u0000-\u00ff]/.test(name)) name = Buffer.from(name, 'latin1').toString('utf8');
  name = path.basename(name.replace(/\\/g, '/'));
  name = name.replace(/[\u0000-\u001f\u007f<>:"|?*]/g, '_').replace(/^\.+/, '').trim();
  if (name.length > 120) name = name.slice(-120);
  return name || 'file';
}

// Check the first bytes so "virus.png" that is not really a PNG gets rejected.
export async function sniffMatches(filePath, ext) {
  const fh = await fs.open(filePath, 'r');
  try {
    const buf = Buffer.alloc(4096);
    const { bytesRead } = await fh.read(buf, 0, 4096, 0);
    const b = buf.subarray(0, bytesRead);
    const at = (sig, off = 0) => b.length >= off + sig.length && sig.every((v, i) => b[off + i] === v);
    switch (ext) {
      case 'png': return at([0x89, 0x50, 0x4e, 0x47]);
      case 'jpg': case 'jpeg': return at([0xff, 0xd8, 0xff]);
      case 'webp': return at([0x52, 0x49, 0x46, 0x46]) && at([0x57, 0x45, 0x42, 0x50], 8);
      case 'pdf': return b.subarray(0, 1024).includes('%PDF');
      case 'docx': return at([0x50, 0x4b]);
      case 'doc': return at([0xd0, 0xcf, 0x11, 0xe0]);
      default: return !b.includes(0); // text files must not contain NUL bytes
    }
  } finally {
    await fh.close();
  }
}
