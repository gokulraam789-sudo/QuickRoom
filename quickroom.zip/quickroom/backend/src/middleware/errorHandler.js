import multer from 'multer';
import { AppError } from '../utils/errors.js';

export const notFound = (req, res) => res.status(404).json({ error: { code: 'NOT_FOUND', message: 'Not found.' } });

// Friendly JSON only. Internals are logged on the server, never sent to the browser.
export function errorHandler(err, req, res, next) {
  if (res.headersSent) return next(err);
  if (err instanceof AppError) return res.status(err.status).json({ error: { code: err.code, message: err.message, ...err.extra } });
  if (err instanceof multer.MulterError) {
    if (err.code === 'LIMIT_FILE_SIZE') return res.status(413).json({ error: { code: 'FILE_TOO_LARGE', message: 'That file is too large.' } });
    return res.status(400).json({ error: { code: 'BAD_UPLOAD', message: 'The upload could not be processed.' } });
  }
  if (err.type === 'entity.too.large') return res.status(413).json({ error: { code: 'TOO_LARGE', message: 'That is too large to share.' } });
  if (err.type === 'entity.parse.failed') return res.status(400).json({ error: { code: 'BAD_REQUEST', message: 'Malformed request.' } });
  console.error('[error]', err.message);
  res.status(500).json({ error: { code: 'SERVER_ERROR', message: 'Something went wrong on our side. Please try again.' } });
}
