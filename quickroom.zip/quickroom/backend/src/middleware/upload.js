import multer from 'multer';
import crypto from 'node:crypto';
import { config } from '../config.js';
import { AppError } from '../utils/errors.js';
import { FILE_TYPES, extOf, sanitizeFilename } from '../utils/fileTypes.js';
import { incomingDir } from '../services/storageService.js';

// Uploads first land in temp/incoming with a random name (the user's filename is never used on disk).
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, incomingDir()),
  filename: (req, file, cb) => cb(null, crypto.randomBytes(16).toString('hex')),
});

export const upload = multer({
  storage,
  limits: { fileSize: config.maxFileBytes, files: 1, fields: 0, parts: 2 },
  fileFilter: (req, file, cb) => {
    const ext = extOf(sanitizeFilename(file.originalname));
    if (!FILE_TYPES[ext]) return cb(new AppError(415, 'UNSUPPORTED_TYPE', `“.${ext || '?'}” files aren’t supported.`));
    cb(null, true);
  },
});
