import rateLimit from 'express-rate-limit';

const make = (windowMs, limit, message) =>
  rateLimit({
    windowMs, limit, standardHeaders: 'draft-7', legacyHeaders: false,
    handler: (req, res) => res.status(429).json({ error: { code: 'TOO_MANY_REQUESTS', message } }),
  });

export const apiLimiter = make(60_000, 600, 'Too many requests. Please slow down.');
export const createRoomLimiter = make(15 * 60_000, 20, 'You have created a lot of rooms. Please wait a few minutes.');
export const joinLimiter = make(15 * 60_000, 40, 'Too many join attempts. Please wait a few minutes.');
export const uploadLimiter = make(60_000, 60, 'You are uploading too quickly. Please wait a moment.');
