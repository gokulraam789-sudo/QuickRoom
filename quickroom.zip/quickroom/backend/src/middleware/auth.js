import * as roomService from '../services/roomService.js';

// Bearer token in the Authorization header (never in the URL). Also re-checks room expiry on every request.
export function requireRoom(req, res, next) {
  try {
    const header = req.headers.authorization || '';
    const token = header.startsWith('Bearer ') ? header.slice(7) : '';
    const { room, session } = roomService.authenticate(token);
    req.room = room;
    req.session = session;
    req.token = token;
    next();
  } catch (err) {
    next(err);
  }
}
