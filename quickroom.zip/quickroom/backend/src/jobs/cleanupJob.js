import { config } from '../config.js';
import * as roomService from '../services/roomService.js';

// Runs on the server only; it does not care whether any browser is open.
export function startCleanupJob() {
  const timer = setInterval(() => {
    roomService.sweep().catch((err) => console.error('[cleanup] sweep failed:', err.message));
  }, config.sweepIntervalMs);
  timer.unref();
  return () => clearInterval(timer);
}
