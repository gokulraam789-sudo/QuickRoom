import express from 'express';
import helmet from 'helmet';
import cors from 'cors';
import { config } from './config.js';
import routes from './routes/index.js';
import { apiLimiter } from './middleware/rateLimits.js';
import { errorHandler, notFound } from './middleware/errorHandler.js';

export function createApp() {
  const app = express();
  app.set('trust proxy', config.trustProxy);
  app.disable('x-powered-by');
  app.use(helmet());
  app.use(cors({
    origin: (origin, cb) => cb(null, !origin || config.clientOrigins.includes(origin)),
    methods: ['GET', 'POST', 'DELETE'],
    allowedHeaders: ['Content-Type', 'Authorization'],
    exposedHeaders: ['X-Preview-Truncated'],
  }));
  app.use('/api', apiLimiter);
  app.use(express.json({ limit: '200kb' }));
  app.use('/api', routes);
  app.use(notFound);
  app.use(errorHandler);
  return app;
}
