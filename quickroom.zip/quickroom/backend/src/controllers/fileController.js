import { pipeline } from 'node:stream';
import { config } from '../config.js';
import * as roomService from '../services/roomService.js';
import * as storage from '../services/storageService.js';
import * as realtime from '../sockets/realtime.js';
import { AppError } from '../utils/errors.js';
import { newId } from '../utils/ids.js';
import { FILE_TYPES, extOf, sanitizeFilename, sniffMatches } from '../utils/fileTypes.js';

// Runs BEFORE multer: refuse early (limits, busy) and make sure the reservation is always released.
export function reserve(req, res, next) {
  try {
    const declared = Number(req.headers['content-length']);
    if (!Number.isFinite(declared) || declared <= 0) throw new AppError(411, 'LENGTH_REQUIRED', 'Upload size could not be determined.');
    roomService.reserveUpload(req.room, declared);
    const room = req.room;
    let released = false;
    res.on('close', () => { if (!released) { released = true; roomService.releaseUpload(room, declared); } });
    next();
  } catch (err) {
    next(err);
  }
}

export async function create(req, res) {
  const file = req.file;
  if (!file) throw new AppError(400, 'NO_FILE', 'No file was received.');
  try {
    const room = roomService.requireActive(req.room.id); // may have expired during the upload
    const name = sanitizeFilename(file.originalname);
    const ext = extOf(name);
    const type = FILE_TYPES[ext];
    if (!type) throw new AppError(415, 'UNSUPPORTED_TYPE', `“.${ext || '?'}” files aren’t supported.`);
    if (!(await sniffMatches(file.path, ext))) throw new AppError(415, 'FILE_CONTENT_MISMATCH', 'That file’s contents don’t match its type.');
    roomService.assertCanStore(room, file.size);

    const id = newId();
    await storage.commitUpload(room.id, id, file.path);
    if (room.status !== 'active') { // expired while we were moving the file
      await storage.deleteFile(room.id, id);
      throw new AppError(410, 'ROOM_EXPIRED', 'This room has expired.', { cleanupConfirmed: false });
    }
    const meta = { id, name, ext, kind: type.kind, mime: type.mime, size: file.size, ownerId: req.session.participantId, createdAt: Date.now() };
    const pub = roomService.addFile(room, meta);
    realtime.emitToRoom(room.id, 'file:added', { file: pub });
    res.status(201).json({ file: pub });
  } catch (err) {
    await storage.discardIncoming(file.path); // incomplete / rejected uploads never linger
    throw err;
  }
}

const asciiName = (n) => n.replace(/[^\x20-\x7e]/g, '_').replace(/["\\]/g, '_');

function sendStream(res, stream) {
  pipeline(stream, res, (err) => { if (err && !res.headersSent) res.status(500).json({ error: { code: 'READ_FAILED', message: 'The file could not be read.' } }); });
}

async function lookup(req) {
  const f = roomService.getFile(req.room, req.params.id);
  const st = await storage.statFile(req.room.id, f.id);
  if (!st) throw new AppError(404, 'FILE_NOT_FOUND', 'That file is no longer available.');
  return { f, st };
}

export async function download(req, res) {
  const { f, st } = await lookup(req);
  res.set({
    'Content-Type': 'application/octet-stream', // never let the browser interpret it
    'Content-Disposition': `attachment; filename="${asciiName(f.name)}"; filename*=UTF-8''${encodeURIComponent(f.name)}`,
    'Content-Length': st.size, 'X-Content-Type-Options': 'nosniff', 'Cache-Control': 'no-store',
  });
  sendStream(res, storage.readStream(req.room.id, f.id));
}

export async function preview(req, res) {
  const { f, st } = await lookup(req);
  if (f.kind === 'binary') throw new AppError(415, 'NO_PREVIEW', 'No preview is available for this file type.');
  const isText = f.kind === 'text';
  const truncated = isText && st.size > config.previewMaxBytes;
  res.set({
    'Content-Type': isText ? 'text/plain; charset=utf-8' : f.mime,
    'Content-Length': truncated ? config.previewMaxBytes : st.size,
    'X-Content-Type-Options': 'nosniff', 'Cache-Control': 'no-store',
    'Content-Security-Policy': "default-src 'none'; sandbox", 'X-Preview-Truncated': String(truncated),
  });
  sendStream(res, storage.readStream(req.room.id, f.id, truncated ? { start: 0, end: config.previewMaxBytes - 1 } : undefined));
}

export async function remove(req, res) {
  const f = roomService.getFile(req.room, req.params.id);
  if (f.ownerId !== req.session.participantId) throw new AppError(403, 'FORBIDDEN', 'You can only delete files you uploaded.');
  await roomService.removeFile(req.room, f.id);
  realtime.emitToRoom(req.room.id, 'file:removed', { id: f.id });
  res.json({ ok: true });
}
