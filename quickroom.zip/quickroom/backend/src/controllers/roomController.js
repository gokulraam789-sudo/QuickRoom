import * as roomService from '../services/roomService.js';
import * as realtime from '../sockets/realtime.js';

const sessionPayload = (room, session) => ({
  roomId: room.id, token: session.token, participantId: session.participantId,
  expiresAt: room.expiresAt, serverTime: Date.now(),
});

export async function create(req, res) {
  const { durationMinutes, password } = req.body ?? {};
  const { room, session } = await roomService.createRoom({ durationMinutes, password });
  res.status(201).json(sessionPayload(room, session));
}

export async function join(req, res) {
  const { roomId, password } = req.body ?? {};
  const { room, session } = await roomService.joinRoom({ roomId, password, ip: req.ip });
  res.json(sessionPayload(room, session));
}

export function state(req, res) {
  const { room, session } = req;
  res.json({
    room: { id: room.id, createdAt: room.createdAt, expiresAt: room.expiresAt },
    serverTime: Date.now(),
    files: roomService.listFiles(room),
    notes: roomService.listNotes(room),
    participants: realtime.participantCount(room.id),
    me: { participantId: session.participantId },
  });
}

export function leave(req, res) {
  roomService.closeSession(req.token);
  res.json({ ok: true });
}
