import * as roomService from '../services/roomService.js';
import * as realtime from '../sockets/realtime.js';

export function create(req, res) {
  const { kind, content, language } = req.body ?? {};
  const note = roomService.addNote(req.room, { kind, content, language, ownerId: req.session.participantId });
  realtime.emitToRoom(req.room.id, 'note:added', { note });
  res.status(201).json({ note });
}

export function remove(req, res) {
  roomService.removeNote(req.room, req.params.id, req.session.participantId);
  realtime.emitToRoom(req.room.id, 'note:removed', { id: req.params.id });
  res.json({ ok: true });
}
