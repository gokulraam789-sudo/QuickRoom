import 'dotenv/config';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const int = (value, fallback) => {
  const n = Number.parseInt(value, 10);
  return Number.isFinite(n) && n > 0 ? n : fallback;
};
const MB = 1024 * 1024;

export const config = {
  port: int(process.env.PORT, 4000),
  clientOrigins: (process.env.CLIENT_ORIGINS || 'http://localhost:5173').split(',').map((s) => s.trim()).filter(Boolean),
  trustProxy: Number.parseInt(process.env.TRUST_PROXY ?? '1', 10) || 0,
  tempDir: path.resolve(process.env.TEMP_DIR || path.join(here, '..', 'temp')),

  maxRoomMinutes: 30, // hard ceiling, not configurable
  maxActiveRooms: int(process.env.MAX_ACTIVE_ROOMS, 200),

  maxFileBytes: int(process.env.MAX_FILE_MB, 25) * MB,
  roomStorageBytes: int(process.env.ROOM_STORAGE_MB, 100) * MB,
  maxFilesPerRoom: int(process.env.MAX_FILES_PER_ROOM, 30),
  maxConcurrentUploadsPerRoom: 3,
  previewMaxBytes: 200 * 1024,

  maxNotesPerRoom: 100,
  maxTextChars: 20000,
  maxCodeChars: 50000,

  bcryptRounds: int(process.env.BCRYPT_ROUNDS, 10),
  maxPasswordAttempts: int(process.env.MAX_PASSWORD_ATTEMPTS, 5),
  lockoutMs: int(process.env.LOCKOUT_SECONDS, 300) * 1000,

  sweepIntervalMs: int(process.env.SWEEP_INTERVAL_MS, 5000),
  incomingMaxAgeMs: 10 * 60 * 1000,
};
