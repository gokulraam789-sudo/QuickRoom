import { Router } from 'express';
import { config } from '../config.js';
import { wrap } from '../utils/asyncHandler.js';
import { requireRoom } from '../middleware/auth.js';
import { upload } from '../middleware/upload.js';
import { createRoomLimiter, joinLimiter, uploadLimiter } from '../middleware/rateLimits.js';
import { ALLOWED_DURATIONS, LANGUAGES } from '../services/roomService.js';
import { FILE_TYPES } from '../utils/fileTypes.js';
import * as rooms from '../controllers/roomController.js';
import * as files from '../controllers/fileController.js';
import * as notes from '../controllers/noteController.js';

const r = Router();

r.get('/health', (req, res) => res.json({ ok: true }));
r.get('/config', (req, res) => res.json({
  durations: ALLOWED_DURATIONS, languages: LANGUAGES, allowedExtensions: Object.keys(FILE_TYPES),
  maxFileBytes: config.maxFileBytes, roomStorageBytes: config.roomStorageBytes, maxFilesPerRoom: config.maxFilesPerRoom,
  maxTextChars: config.maxTextChars, maxCodeChars: config.maxCodeChars,
}));

// The room is identified by the session token, never by an ID in the URL, so a client cannot "ask for" another room.
r.post('/rooms', createRoomLimiter, wrap(rooms.create));
r.post('/rooms/join', joinLimiter, wrap(rooms.join));
r.get('/rooms/state', requireRoom, rooms.state);
r.post('/rooms/leave', requireRoom, rooms.leave);

r.post('/rooms/files', uploadLimiter, requireRoom, files.reserve, upload.single('file'), wrap(files.create));
r.get('/rooms/files/:id/download', requireRoom, wrap(files.download));
r.get('/rooms/files/:id/preview', requireRoom, wrap(files.preview));
r.delete('/rooms/files/:id', requireRoom, wrap(files.remove));

r.post('/rooms/notes', requireRoom, notes.create);
r.delete('/rooms/notes/:id', requireRoom, notes.remove);

export default r;
