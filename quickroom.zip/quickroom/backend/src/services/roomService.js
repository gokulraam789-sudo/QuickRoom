// All room state lives here, in memory. This module is the single authority on who may do what and when a room dies.
import bcrypt from 'bcrypt';
import { config } from '../config.js';
import { AppError } from '../utils/errors.js';
import { newRoomId, newToken, newId, normalizeRoomId, isValidRoomId } from '../utils/ids.js';
import * as storage from './storageService.js';
import * as realtime from '../sockets/realtime.js';

export const ALLOWED_DURATIONS = [1, 5, 10, 15, 20, 25, 30];
export const LANGUAGES = ['python', 'javascript', 'typescript', 'java', 'c', 'cpp', 'html', 'css', 'sql', 'json', 'plaintext'];

const KEEP_MS = 60 * 60 * 1000;
const rooms = new Map();        // roomId -> room
const sessions = new Map();     // token -> { roomId, participantId }
const deadSessions = new Map(); // token -> { roomId, at }  (so a stale tab learns "expired", not just "unauthorized")
const tombstones = new Map();   // roomId -> expiredAt       (id only; can never restore access)
const attempts = new Map();     // `${ip}|${roomId}` -> { count, lockedUntil, last }

export const peek = (roomId) => rooms.get(roomId); // used by tests

const expiredError = (roomId) =>
  new AppError(410, 'ROOM_EXPIRED', 'This room has expired.', { cleanupConfirmed: !rooms.has(roomId) });

function validatePassword(pw) {
  if (typeof pw !== 'string' || pw.length < 6) throw new AppError(400, 'WEAK_PASSWORD', 'Password must be at least 6 characters.');
  if (Buffer.byteLength(pw) > 72) throw new AppError(400, 'WEAK_PASSWORD', 'Password is too long (max 72 bytes).');
}

function openSession(room) {
  const token = newToken();
  const participantId = newId();
  sessions.set(token, { roomId: room.id, participantId });
  return { token, participantId };
}

export async function createRoom({ durationMinutes, password } = {}) {
  const minutes = Number(durationMinutes);
  if (!ALLOWED_DURATIONS.includes(minutes)) throw new AppError(400, 'INVALID_DURATION', 'Pick a duration of 1, 5, 10, 15, 20, 25 or 30 minutes.');
  validatePassword(password);
  const active = [...rooms.values()].filter((r) => r.status === 'active').length;
  if (active >= config.maxActiveRooms) throw new AppError(503, 'SERVER_BUSY', 'The server is busy right now. Please try again shortly.');

  let id;
  do { id = newRoomId(); } while (rooms.has(id) || tombstones.has(id));

  const passwordHash = await bcrypt.hash(password, config.bcryptRounds); // plaintext is never stored or logged
  const now = Date.now();
  const lifetime = Math.min(minutes, config.maxRoomMinutes) * 60_000;
  const room = {
    id, passwordHash, createdAt: now, expiresAt: now + lifetime, // the server decides the expiry
    status: 'active', cleanupPending: false, expiring: null,
    files: new Map(), notes: [], storageUsed: 0, reservedBytes: 0, activeUploads: 0, timer: null,
  };
  room.timer = setTimeout(() => expireRoom(room).catch(() => {}), lifetime + 50);
  room.timer.unref();
  rooms.set(id, room);
  return { room, session: openSession(room) };
}

// Every protected operation funnels through here, so expiry is enforced server-side on each call.
export function requireActive(roomId) {
  const room = rooms.get(roomId);
  if (!room) {
    if (tombstones.has(roomId)) throw expiredError(roomId);
    throw new AppError(404, 'ROOM_NOT_FOUND', 'We couldn’t find that room. Check the Room ID.');
  }
  if (room.status !== 'active' || Date.now() >= room.expiresAt) {
    expireRoom(room).catch(() => {});
    throw expiredError(roomId);
  }
  return room;
}

export function authenticate(token) {
  if (!token || typeof token !== 'string') throw new AppError(401, 'UNAUTHORIZED', 'Please join the room first.');
  const dead = deadSessions.get(token);
  if (dead) throw expiredError(dead.roomId);
  const s = sessions.get(token);
  if (!s) throw new AppError(401, 'UNAUTHORIZED', 'Your session is no longer valid. Please join the room again.');
  return { room: requireActive(s.roomId), session: { ...s, token } };
}

export function closeSession(token) {
  sessions.delete(token);
  realtime.disconnectToken(token);
}

function checkLock(key) {
  const a = attempts.get(key);
  if (a?.lockedUntil > Date.now()) {
    const retryAfterSeconds = Math.ceil((a.lockedUntil - Date.now()) / 1000);
    throw new AppError(429, 'TOO_MANY_ATTEMPTS', `Too many incorrect attempts. Try again in ${retryAfterSeconds} seconds.`, { retryAfterSeconds });
  }
}
function recordFailure(key) {
  const now = Date.now();
  let a = attempts.get(key);
  if (!a || (a.lockedUntil && a.lockedUntil <= now)) a = { count: 0, lockedUntil: 0 };
  a.count += 1;
  a.last = now;
  if (a.count >= config.maxPasswordAttempts) { a.lockedUntil = now + config.lockoutMs; a.count = 0; }
  attempts.set(key, a);
}

export async function joinRoom({ roomId, password, ip }) {
  const id = normalizeRoomId(roomId);
  if (!isValidRoomId(id) || typeof password !== 'string') throw new AppError(404, 'ROOM_NOT_FOUND', 'We couldn’t find that room. Check the Room ID.');
  const key = `${ip}|${id}`;
  checkLock(key);
  const room = requireActive(id);
  const ok = await bcrypt.compare(password, room.passwordHash);
  if (!ok) {
    recordFailure(key);
    throw new AppError(401, 'INVALID_CREDENTIALS', 'Incorrect Room ID or password.');
  }
  attempts.delete(key);
  requireActive(id); // the room may have expired while bcrypt was running
  return { room, session: openSession(room) };
}

// ---------- files ----------
export const publicFile = (f) => ({ id: f.id, name: f.name, ext: f.ext, kind: f.kind, size: f.size, ownerId: f.ownerId, createdAt: f.createdAt });
export const listFiles = (room) => [...room.files.values()].map(publicFile);

export function reserveUpload(room, declaredBytes) {
  if (declaredBytes > config.maxFileBytes + 64 * 1024) throw new AppError(413, 'FILE_TOO_LARGE', `Files can be at most ${Math.floor(config.maxFileBytes / 1048576)} MB.`);
  if (room.activeUploads >= config.maxConcurrentUploadsPerRoom) throw new AppError(429, 'UPLOAD_BUSY', 'Too many uploads at once. Please wait a moment.');
  if (room.files.size + room.activeUploads >= config.maxFilesPerRoom) throw new AppError(409, 'TOO_MANY_FILES', `This room can hold ${config.maxFilesPerRoom} files.`);
  if (room.storageUsed + room.reservedBytes + declaredBytes > config.roomStorageBytes) throw new AppError(413, 'ROOM_STORAGE_FULL', 'This room’s storage limit has been reached.');
  room.activeUploads += 1;
  room.reservedBytes += declaredBytes;
}
export function releaseUpload(room, declaredBytes) {
  room.activeUploads = Math.max(0, room.activeUploads - 1);
  room.reservedBytes = Math.max(0, room.reservedBytes - declaredBytes);
}
export function assertCanStore(room, size) {
  if (room.files.size >= config.maxFilesPerRoom) throw new AppError(409, 'TOO_MANY_FILES', `This room can hold ${config.maxFilesPerRoom} files.`);
  if (room.storageUsed + size > config.roomStorageBytes) throw new AppError(413, 'ROOM_STORAGE_FULL', 'This room’s storage limit has been reached.');
}
export function addFile(room, meta) {
  if (room.status !== 'active') throw expiredError(room.id);
  room.files.set(meta.id, meta);
  room.storageUsed += meta.size;
  return publicFile(meta);
}
export function getFile(room, fileId) {
  const f = room.files.get(fileId);
  if (!f) throw new AppError(404, 'FILE_NOT_FOUND', 'That file no longer exists.');
  return f;
}
export async function removeFile(room, fileId) {
  const f = getFile(room, fileId);
  room.files.delete(fileId);
  room.storageUsed = Math.max(0, room.storageUsed - f.size);
  await storage.deleteFile(room.id, fileId);
}

// ---------- notes (text + code) ----------
export const publicNote = (n) => ({ id: n.id, kind: n.kind, content: n.content, language: n.language, ownerId: n.ownerId, createdAt: n.createdAt });
export const listNotes = (room) => room.notes.map(publicNote);

export function addNote(room, { kind, content, language, ownerId }) {
  if (kind !== 'text' && kind !== 'code') throw new AppError(400, 'INVALID_NOTE', 'Unknown content type.');
  if (typeof content !== 'string' || !content.trim()) throw new AppError(400, 'EMPTY_NOTE', 'There is nothing to share yet.');
  const limit = kind === 'text' ? config.maxTextChars : config.maxCodeChars;
  if (content.length > limit) throw new AppError(413, 'NOTE_TOO_LARGE', `That is too long (max ${limit.toLocaleString('en-US')} characters).`);
  if (room.notes.length >= config.maxNotesPerRoom) throw new AppError(409, 'TOO_MANY_NOTES', 'This room has reached its limit of shared items.');
  const lang = kind === 'code' ? (LANGUAGES.includes(language) ? language : 'plaintext') : null;
  const note = { id: newId(), kind, content, language: lang, ownerId, createdAt: Date.now() };
  room.notes.unshift(note);
  return publicNote(note);
}
export function removeNote(room, noteId, participantId) {
  const i = room.notes.findIndex((n) => n.id === noteId);
  if (i === -1) throw new AppError(404, 'NOTE_NOT_FOUND', 'That item no longer exists.');
  if (room.notes[i].ownerId !== participantId) throw new AppError(403, 'FORBIDDEN', 'You can only delete items you shared.');
  room.notes.splice(i, 1);
}

// ---------- expiry & cleanup ----------
async function attemptCleanup(room) {
  let ok = false;
  try { ok = await storage.deleteRoomFiles(room.id); } catch { ok = false; }
  if (ok) { rooms.delete(room.id); room.cleanupPending = false; } else { room.cleanupPending = true; } // stays inaccessible either way
  return ok;
}

export function expireRoom(room) {
  if (room.expiring) return room.expiring;
  // 1) Synchronously make the room unreachable BEFORE any await.
  room.status = 'expired';
  clearTimeout(room.timer);
  for (const [token, s] of sessions) {
    if (s.roomId === room.id) { sessions.delete(token); deadSessions.set(token, { roomId: room.id, at: Date.now() }); }
  }
  tombstones.set(room.id, Date.now());
  room.files.clear();
  room.notes = [];
  // 2) Then delete files and tell everyone what really happened.
  room.expiring = (async () => {
    const ok = await attemptCleanup(room);
    realtime.notifyExpired(room.id, { cleanupConfirmed: ok });
  })();
  return room.expiring;
}

let sweeping = false;
export async function sweep() {
  if (sweeping) return;
  sweeping = true;
  try {
    const now = Date.now();
    for (const room of [...rooms.values()]) {
      if (room.status === 'active' && now >= room.expiresAt) await expireRoom(room);
      else if (room.status === 'expired' && room.cleanupPending) { await room.expiring; await attemptCleanup(room); }
    }
    for (const [k, t] of tombstones) if (now - t > KEEP_MS) tombstones.delete(k);
    for (const [k, v] of deadSessions) if (now - v.at > KEEP_MS) deadSessions.delete(k);
    for (const [k, a] of attempts) if (now - (a.last ?? 0) > config.lockoutMs + 15 * 60_000) attempts.delete(k);
    await storage.sweepIncoming(config.incomingMaxAgeMs);
    await storage.sweepOrphans(new Set(rooms.keys()));
  } finally {
    sweeping = false;
  }
}
