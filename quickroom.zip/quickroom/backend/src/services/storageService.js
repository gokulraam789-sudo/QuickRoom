// Temporary file storage on local disk. Nothing in here knows about Express or room objects,
// so it can be swapped for S3/R2/GCS later by re-implementing the same exports.
import fs from 'node:fs/promises';
import { createReadStream } from 'node:fs';
import path from 'node:path';
import { config } from '../config.js';

const ROOMS = path.join(config.tempDir, 'rooms');
const INCOMING = path.join(config.tempDir, 'incoming'); // uploads land here first
const ROOM_RE = /^[A-HJ-NP-Z2-9]{12}$/;
const FILE_RE = /^[a-f0-9]{24}$/;

export const incomingDir = () => INCOMING;

export async function init() {
  await fs.mkdir(ROOMS, { recursive: true });
  await fs.mkdir(INCOMING, { recursive: true });
}

async function emptyDir(dir) {
  let n = 0;
  for (const entry of await fs.readdir(dir).catch(() => [])) {
    await fs.rm(path.join(dir, entry), { recursive: true, force: true });
    n++;
  }
  return n;
}

// Room metadata lives in memory, so after a restart every file on disk is abandoned by definition.
export async function wipeAll() {
  await init();
  return (await emptyDir(ROOMS)) + (await emptyDir(INCOMING));
}

function roomDir(roomId) {
  if (!ROOM_RE.test(roomId)) throw new Error('Invalid room id');
  return path.join(ROOMS, roomId);
}
export function filePath(roomId, fileId) {
  if (!FILE_RE.test(fileId)) throw new Error('Invalid file id'); // blocks path traversal
  return path.join(roomDir(roomId), fileId);
}

export async function commitUpload(roomId, fileId, tmpPath) {
  await fs.mkdir(roomDir(roomId), { recursive: true });
  await fs.rename(tmpPath, filePath(roomId, fileId));
}
export async function statFile(roomId, fileId) {
  try { return await fs.stat(filePath(roomId, fileId)); } catch { return null; }
}
export const readStream = (roomId, fileId, opts) => createReadStream(filePath(roomId, fileId), opts);
export const deleteFile = (roomId, fileId) => fs.rm(filePath(roomId, fileId), { force: true });
export const discardIncoming = (p) => fs.rm(p, { force: true }).catch(() => {});

// Returns true only when the directory is verified gone.
export async function deleteRoomFiles(roomId) {
  const dir = roomDir(roomId);
  await fs.rm(dir, { recursive: true, force: true });
  try { await fs.access(dir); return false; } catch { return true; }
}

export async function sweepIncoming(maxAgeMs) {
  const now = Date.now();
  for (const entry of await fs.readdir(INCOMING).catch(() => [])) {
    const p = path.join(INCOMING, entry);
    const st = await fs.stat(p).catch(() => null);
    if (st && now - st.mtimeMs > maxAgeMs) await fs.rm(p, { recursive: true, force: true });
  }
}

// Delete any room directory that no known room owns (failed cleanups, crashes, races).
export async function sweepOrphans(knownRoomIds) {
  for (const entry of await fs.readdir(ROOMS).catch(() => [])) {
    if (!knownRoomIds.has(entry)) await fs.rm(path.join(ROOMS, entry), { recursive: true, force: true });
  }
}
