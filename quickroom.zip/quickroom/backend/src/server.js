import http from 'node:http';
import { config } from './config.js';
import { createApp } from './app.js';
import { attachSockets } from './sockets/index.js';
import { startCleanupJob } from './jobs/cleanupJob.js';
import * as storage from './services/storageService.js';

async function main() {
  // Startup cleanup: metadata is in memory, so any file left on disk from a previous run is abandoned.
  const removed = await storage.wipeAll();
  console.log(`[startup] temp storage ready at ${config.tempDir} (removed ${removed} leftover item(s))`);

  const server = http.createServer(createApp());
  const io = attachSockets(server);
  const stopJob = startCleanupJob();

  server.listen(config.port, () => console.log(`[startup] QuickRoom API listening on http://localhost:${config.port}`));

  let closing = false;
  const shutdown = async (signal) => {
    if (closing) return;
    closing = true;
    console.log(`[shutdown] ${signal} received, cleaning up…`);
    stopJob();
    io.close();
    server.close();
    await storage.wipeAll().catch(() => {});
    process.exit(0);
  };
  process.on('SIGINT', () => shutdown('SIGINT'));
  process.on('SIGTERM', () => shutdown('SIGTERM'));
}

main().catch((err) => { console.error('Fatal startup error:', err); process.exit(1); });
