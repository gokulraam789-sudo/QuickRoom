import { Download, Eye, File as FileIcon, FileCode, FileImage, FileText, Trash2 } from 'lucide-react';
import { formatBytes, formatTime } from '../utils/format';

const iconFor = (f) => (f.kind === 'image' ? FileImage : f.kind === 'pdf' || f.kind === 'binary' ? FileText : f.kind === 'text' ? FileCode : FileIcon);

export default function FileList({ files, meId, selectedId, onSelect, onDownload, onDelete }) {
  if (files.length === 0) {
    return (
      <div className="card px-6 py-10 text-center">
        <FileIcon className="mx-auto h-8 w-8 text-slate-600" />
        <p className="mt-3 text-sm font-medium text-slate-300">No files yet</p>
        <p className="mt-1 text-xs text-slate-500">Upload a file here and it appears instantly on every device in this room.</p>
      </div>
    );
  }
  return (
    <ul className="space-y-2">
      {files.map((f) => {
        const Icon = iconFor(f);
        const mine = f.ownerId === meId;
        return (
          <li key={f.id} className={`card flex items-center gap-3 p-3 transition ${selectedId === f.id ? 'border-indigo-400/60 bg-indigo-500/10' : ''}`}>
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-white/5 text-indigo-300"><Icon className="h-5 w-5" /></div>
            <div className="min-w-0 flex-1">
              <p className="truncate text-sm font-medium" title={f.name}>{f.name}</p>
              <p className="text-xs text-slate-400">
                <span className="uppercase">{f.ext}</span> · {formatBytes(f.size)} · {mine ? 'You' : 'Someone'} · {formatTime(f.createdAt)} · <span className="text-emerald-400">Ready</span>
              </p>
            </div>
            <div className="flex shrink-0 items-center">
              {f.kind !== 'binary' && <button className="icon-btn" onClick={() => onSelect(f.id)} title="Preview" aria-label={`Preview ${f.name}`}><Eye className="h-4 w-4" /></button>}
              <button className="icon-btn" onClick={() => onDownload(f)} title="Download" aria-label={`Download ${f.name}`}><Download className="h-4 w-4" /></button>
              {mine && <button className="icon-btn hover:!text-rose-300" onClick={() => onDelete(f)} title="Delete" aria-label={`Delete ${f.name}`}><Trash2 className="h-4 w-4" /></button>}
            </div>
          </li>
        );
      })}
    </ul>
  );
}
