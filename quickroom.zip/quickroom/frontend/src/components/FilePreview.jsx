import { useEffect, useState } from 'react';
import { Loader2, X } from 'lucide-react';
import { api } from '../services/api';
import CodeBlock, { EXT_LANG } from './CodeBlock';

// Loads the file through the authorized API as a blob, so no public file URL ever exists.
export default function FilePreview({ file, onClose }) {
  const [state, setState] = useState({ loading: true });

  useEffect(() => {
    let url = null;
    let cancelled = false;
    setState({ loading: true });
    (async () => {
      try {
        const { blob, truncated } = await api.fetchFile(file.id, 'preview');
        if (cancelled) return;
        if (file.kind === 'text') setState({ text: await blob.text(), truncated });
        else { url = URL.createObjectURL(blob); setState({ url }); }
      } catch (e) { if (!cancelled) setState({ error: e.message }); }
    })();
    return () => { cancelled = true; if (url) URL.revokeObjectURL(url); };
  }, [file.id, file.kind]);

  return (
    <div className="card overflow-hidden">
      <div className="flex items-center justify-between border-b border-white/10 px-4 py-2.5">
        <p className="truncate text-sm font-medium">{file.name}</p>
        <button className="icon-btn" onClick={onClose} aria-label="Close preview"><X className="h-4 w-4" /></button>
      </div>
      <div className="p-3">
        {state.loading && <div className="flex justify-center py-12"><Loader2 className="h-6 w-6 animate-spin text-indigo-300" /></div>}
        {state.error && <p className="py-8 text-center text-sm text-rose-300">{state.error}</p>}
        {state.url && file.kind === 'image' && <img src={state.url} alt={file.name} className="mx-auto max-h-[60vh] rounded-lg object-contain" />}
        {state.url && file.kind === 'pdf' && (
          <>
            <iframe src={state.url} title={file.name} className="h-[60vh] w-full rounded-lg bg-white" />
            <p className="mt-2 text-center text-xs text-slate-500">PDF not showing? Some mobile browsers can’t preview PDFs — use Download.</p>
          </>
        )}
        {state.text !== undefined && (
          <>
            <CodeBlock code={state.text} language={EXT_LANG[file.ext] || 'plaintext'} className="max-h-[60vh]" />
            {state.truncated && <p className="mt-2 text-xs text-amber-300">Preview shows the first 200 KB only. Download the file for the rest.</p>}
          </>
        )}
      </div>
    </div>
  );
}
