import { Clock, LogOut, Share2, Users } from 'lucide-react';
import Logo from './Logo';
import CopyButton from './CopyButton';
import { formatCountdown, formatRoomId } from '../utils/format';

export default function RoomHeader({ roomId, ms, connected, participants, onLeave, onInvite }) {
  const warning = ms !== null && ms <= 60_000;
  const critical = ms !== null && ms <= 10_000;
  const status = !connected ? 'Reconnecting…' : ms === 0 ? 'Closing…' : warning ? 'Closing soon' : 'Active';
  const dot = !connected ? 'bg-amber-400' : warning ? 'bg-amber-400' : 'bg-emerald-400';

  return (
    <header className="sticky top-0 z-30 border-b border-white/10 bg-slate-950/85 backdrop-blur">
      <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-x-4 gap-y-2 px-4 py-3">
        <div className="flex items-center gap-4">
          <Logo />
          <div className="hidden items-center gap-1 rounded-lg border border-white/10 bg-white/5 py-1 pl-3 pr-1 sm:flex">
            <span className="font-mono text-sm tracking-widest text-slate-200">{formatRoomId(roomId)}</span>
            <CopyButton text={roomId} title="Copy Room ID" />
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-2 sm:gap-3">
          <div className={`flex items-center gap-2 rounded-lg border px-3 py-1.5 text-sm font-medium ${critical ? 'animate-pulse border-rose-500/40 bg-rose-500/10 text-rose-300' : warning ? 'border-amber-500/40 bg-amber-500/10 text-amber-300' : 'border-white/10 bg-white/5 text-slate-200'}`}>
            <Clock className="h-4 w-4" />
            <span className="hidden sm:inline">Room expires in</span>
            <span className="font-mono tabular-nums" aria-live="off">{ms === null ? '--:--' : formatCountdown(ms)}</span>
          </div>
          <div className="hidden items-center gap-1.5 text-xs text-slate-300 md:flex"><span className={`h-2 w-2 rounded-full ${dot}`} />{status}</div>
          <div className="flex items-center gap-1.5 text-sm text-slate-300" title="People in this room"><Users className="h-4 w-4" />{participants}</div>
          {onInvite && <button className="btn-ghost !px-3 !py-1.5" onClick={onInvite}><Share2 className="h-4 w-4" /><span className="hidden sm:inline">Invite</span></button>}
          <button className="btn-ghost !px-3 !py-1.5" onClick={onLeave}><LogOut className="h-4 w-4" /><span className="hidden sm:inline">Leave</span></button>
        </div>
      </div>
      {warning && ms > 0 && (
        <div className="bg-amber-500/10 px-4 py-1.5 text-center text-xs text-amber-200">
          This room closes in under a minute. Download anything you need now — it can’t be extended.
        </div>
      )}
    </header>
  );
}
