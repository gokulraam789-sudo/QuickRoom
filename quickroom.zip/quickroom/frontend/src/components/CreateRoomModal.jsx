import { useEffect, useState } from 'react';
import { Check, Eye, EyeOff, Loader2, Share2, Wand2 } from 'lucide-react';
import Modal from './Modal';
import CopyButton from './CopyButton';
import { api } from '../services/api';
import { formatRoomId, generatePassword } from '../utils/format';

const DURATIONS = [1, 5, 10, 15, 20, 25, 30];

export default function CreateRoomModal({ open, onClose, onEnter }) {
  const [duration, setDuration] = useState(30);
  const [password, setPassword] = useState('');
  const [show, setShow] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [created, setCreated] = useState(null);

  useEffect(() => { if (open) { setCreated(null); setError(''); setPassword(''); setShow(false); } }, [open]);

  const submit = async (e) => {
    e.preventDefault();
    setError('');
    if (password.length < 6) return setError('Password must be at least 6 characters.');
    setBusy(true);
    try {
      const r = await api.createRoom(duration, password);
      setCreated({ roomId: r.roomId, password });
    } catch (err) { setError(err.message); } finally { setBusy(false); }
  };

  const shareText = created ? `Join my QuickRoom\nRoom ID: ${formatRoomId(created.roomId)}\nPassword: ${created.password}\n${window.location.origin}` : '';
  const share = async () => {
    if (navigator.share) { try { await navigator.share({ title: 'QuickRoom', text: shareText }); } catch { /* cancelled */ } }
  };

  return (
    <Modal open={open} onClose={created ? () => {} : onClose} title={created ? 'Room created' : 'Create a room'}>
      {!created ? (
        <form onSubmit={submit} className="space-y-5">
          <div>
            <span className="label">Room duration (max 30 min)</span>
            <div className="grid grid-cols-4 gap-2">
              {DURATIONS.map((d) => (
                <button type="button" key={d} onClick={() => setDuration(d)}
                  className={`rounded-xl border px-2 py-2 text-sm font-medium transition ${duration === d ? 'border-indigo-400 bg-indigo-500/20 text-white' : 'border-white/10 bg-white/5 text-slate-300 hover:bg-white/10'}`}>
                  {d} min
                </button>
              ))}
            </div>
          </div>
          <div>
            <label className="label" htmlFor="cr-pass">Room password</label>
            <div className="relative">
              <input id="cr-pass" className="input pr-10" type={show ? 'text' : 'password'} value={password} maxLength={72}
                onChange={(e) => setPassword(e.target.value)} placeholder="At least 6 characters" autoComplete="new-password" />
              <button type="button" className="icon-btn absolute right-1 top-1" onClick={() => setShow((s) => !s)} aria-label={show ? 'Hide password' : 'Show password'}>
                {show ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
              </button>
            </div>
            <button type="button" className="mt-2 inline-flex items-center gap-1.5 text-xs font-medium text-cyan-300 hover:text-cyan-200"
              onClick={() => { setPassword(generatePassword()); setShow(true); }}>
              <Wand2 className="h-3.5 w-3.5" /> Generate secure password
            </button>
          </div>
          {error && <p className="rounded-lg bg-rose-500/10 px-3 py-2 text-sm text-rose-300" role="alert">{error}</p>}
          <button className="btn-primary w-full" disabled={busy}>{busy && <Loader2 className="h-4 w-4 animate-spin" />} Create Room</button>
        </form>
      ) : (
        <div className="space-y-4">
          <p className="flex items-center gap-2 text-sm text-emerald-300"><Check className="h-4 w-4" /> Your room is live for {duration} minute{duration > 1 ? 's' : ''}.</p>
          <Credential label="Room ID" value={formatRoomId(created.roomId)} copy={created.roomId} />
          <Credential label="Password" value={created.password} copy={created.password} />
          <p className="text-xs text-slate-400">Save the password now — it isn’t shown again after you refresh. Share both with the other device.</p>
          <div className="flex gap-2">
            <CopyButton text={shareText} label="Copy invite" title="Copy invite" className="btn-ghost flex-1" />
            {navigator.share && <button className="btn-ghost" onClick={share}><Share2 className="h-4 w-4" /> Share</button>}
          </div>
          <button className="btn-primary w-full" onClick={() => onEnter(created)}>Enter Room</button>
        </div>
      )}
    </Modal>
  );
}

function Credential({ label, value, copy }) {
  return (
    <div>
      <span className="label">{label}</span>
      <div className="flex items-center justify-between gap-2 rounded-xl border border-white/10 bg-slate-950 px-3.5 py-2.5">
        <code className="select-all break-all font-mono text-base tracking-wider text-cyan-200">{value}</code>
        <CopyButton text={copy} title={`Copy ${label}`} />
      </div>
    </div>
  );
}
