import { useState } from 'react';
import { Code2, Loader2, Send } from 'lucide-react';
import NoteCard from './NoteCard';
import CopyButton from './CopyButton';
import { LANGUAGES } from './CodeBlock';
import { api } from '../services/api';

export default function CodePanel({ notes, meId, config, actions, toast }) {
  const [code, setCode] = useState('');
  const [language, setLanguage] = useState('python');
  const [busy, setBusy] = useState(false);
  const items = notes.filter((n) => n.kind === 'code');
  const max = config?.maxCodeChars ?? 50000;

  const share = async () => {
    if (!code.trim() || busy) return;
    setBusy(true);
    try { const { note } = await api.createNote({ kind: 'code', content: code, language }); actions.addNote(note); setCode(''); }
    catch (e) { toast(e.message, 'error'); } finally { setBusy(false); }
  };
  const remove = async (note) => {
    try { await api.deleteNote(note.id); actions.removeNote(note.id); } catch (e) { toast(e.message, 'error'); }
  };
  const onKeyDown = (e) => {
    if (e.key === 'Tab') { // keep Tab inside the editor and insert two spaces
      e.preventDefault();
      const { selectionStart: s, selectionEnd: en } = e.target;
      setCode(code.slice(0, s) + '  ' + code.slice(en));
      requestAnimationFrame(() => { e.target.selectionStart = e.target.selectionEnd = s + 2; });
    }
  };

  return (
    <div className="space-y-4">
      <div className="card p-3.5">
        <div className="mb-2.5 flex items-center justify-between gap-2">
          <select className="input !w-auto !py-1.5" value={language} onChange={(e) => setLanguage(e.target.value)} aria-label="Language (display only)">
            {LANGUAGES.map(([id, label]) => <option key={id} value={id}>{label}</option>)}
          </select>
          <span className="text-xs text-slate-500">Display only — code is never run</span>
        </div>
        <textarea className="input min-h-[170px] resize-y font-mono text-[13px] leading-relaxed" spellCheck={false} placeholder="Paste or type code…"
          value={code} maxLength={max} onChange={(e) => setCode(e.target.value)} onKeyDown={onKeyDown} aria-label="Code to share" />
        <div className="mt-2.5 flex items-center justify-between gap-2">
          <CopyButton text={code} label="Copy Code" title="Copy Code" className="btn-ghost !py-2" />
          <button className="btn-primary" onClick={share} disabled={!code.trim() || busy}>
            {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />} Share Code
          </button>
        </div>
      </div>
      {items.length === 0 ? (
        <div className="card px-6 py-10 text-center">
          <Code2 className="mx-auto h-8 w-8 text-slate-600" />
          <p className="mt-3 text-sm font-medium text-slate-300">No code shared yet</p>
          <p className="mt-1 text-xs text-slate-500">Pick a language, paste your code and share it with syntax highlighting.</p>
        </div>
      ) : (
        <ul className="space-y-3">{items.map((n) => <NoteCard key={n.id} note={n} mine={n.ownerId === meId} onDelete={remove} />)}</ul>
      )}
    </div>
  );
}
