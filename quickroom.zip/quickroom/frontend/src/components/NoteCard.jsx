import { Trash2 } from 'lucide-react';
import CopyButton from './CopyButton';
import CodeBlock, { LANGUAGES } from './CodeBlock';
import { formatTime } from '../utils/format';

// Text is rendered as a React text node (escaped). It is never injected as HTML.
export default function NoteCard({ note, mine, onDelete }) {
  const langLabel = LANGUAGES.find(([id]) => id === note.language)?.[1];
  return (
    <li className="card p-3.5">
      <div className="mb-2 flex items-center justify-between gap-2">
        <p className="text-xs text-slate-400">
          {mine ? 'You' : 'Someone'} · {formatTime(note.createdAt)}{note.kind === 'code' && langLabel ? ` · ${langLabel}` : ''}
        </p>
        <div className="flex items-center">
          <CopyButton text={note.content} title={note.kind === 'code' ? 'Copy Code' : 'Copy Text'} />
          {mine && <button className="icon-btn hover:!text-rose-300" onClick={() => onDelete(note)} title="Delete" aria-label="Delete"><Trash2 className="h-4 w-4" /></button>}
        </div>
      </div>
      {note.kind === 'code'
        ? <CodeBlock code={note.content} language={note.language} className="max-h-80" />
        : <p className="max-h-80 overflow-auto whitespace-pre-wrap break-words text-sm leading-relaxed">{note.content}</p>}
    </li>
  );
}
