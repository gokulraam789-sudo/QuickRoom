import { AnimatePresence, motion } from 'framer-motion';

export default function Toasts({ list }) {
  return (
    <div className="pointer-events-none fixed inset-x-0 bottom-4 z-[60] flex flex-col items-center gap-2 px-4">
      <AnimatePresence>
        {list.map((t) => (
          <motion.div key={t.id} initial={{ y: 20, opacity: 0 }} animate={{ y: 0, opacity: 1 }} exit={{ opacity: 0 }}
            className={`pointer-events-auto max-w-md rounded-xl border px-4 py-2.5 text-sm shadow-lg ${t.type === 'error' ? 'border-rose-500/30 bg-rose-950 text-rose-100' : 'border-white/10 bg-slate-800 text-slate-100'}`}
            role="status">
            {t.message}
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  );
}
