import { useRef, useState } from 'react';
import { AlertCircle, Loader2, UploadCloud, X } from 'lucide-react';
import { api } from '../services/api';
import { extOf, formatBytes } from '../utils/format';

export default function UploadZone({ config, onUploaded, toast }) {
  const inputRef = useRef(null);
  const queue = useRef(Promise.resolve());
  const [over, setOver] = useState(false);
  const [items, setItems] = useState([]);
  const patch = (id, p) => setItems((l) => l.map((i) => (i.id === id ? { ...i, ...p } : i)));
  const drop = (id) => setItems((l) => l.filter((i) => i.id !== id));

  const run = async (item) => {
    if (item.cancelled) return;
    patch(item.id, { status: 'uploading' });
    const { promise, abort } = api.uploadFile(item.file, (progress) => patch(item.id, { progress }));
    item.abort = abort;
    try {
      const file = await promise;
      onUploaded(file);
      drop(item.id);
    } catch (e) {
      if (e.code === 'ABORTED') drop(item.id); else patch(item.id, { status: 'error', error: e.message });
    }
  };

  const handleFiles = (list) => {
    for (const file of Array.from(list || [])) {
      const ext = extOf(file.name);
      if (config && !config.allowedExtensions.includes(ext)) { toast(`“${file.name}”: .${ext || '?'} files aren’t supported.`, 'error'); continue; }
      if (config && file.size > config.maxFileBytes) { toast(`“${file.name}” is larger than ${formatBytes(config.maxFileBytes)}.`, 'error'); continue; }
      if (file.size === 0) { toast(`“${file.name}” is empty.`, 'error'); continue; }
      const item = { id: Math.random().toString(36).slice(2), file, name: file.name, size: file.size, progress: 0, status: 'queued' };
      setItems((l) => [...l, item]);
      queue.current = queue.current.then(() => run(item)); // one at a time keeps progress clear and the server happy
    }
    if (inputRef.current) inputRef.current.value = '';
  };

  const cancel = (item) => {
    const current = items.find((i) => i.id === item.id);
    if (current?.status === 'uploading') item.abort?.();
    else { item.cancelled = true; drop(item.id); }
  };

  return (
    <div>
      <div
        onDragOver={(e) => { e.preventDefault(); setOver(true); }} onDragLeave={() => setOver(false)}
        onDrop={(e) => { e.preventDefault(); setOver(false); handleFiles(e.dataTransfer.files); }}
        className={`flex flex-col items-center justify-center gap-3 rounded-2xl border-2 border-dashed px-6 py-10 text-center transition ${over ? 'border-cyan-400 bg-cyan-400/10' : 'border-white/15 bg-white/[0.03]'}`}>
        <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-indigo-500/15 text-indigo-300"><UploadCloud className="h-6 w-6" /></div>
        <div>
          <p className="font-medium">Drag & drop files here</p>
          <p className="mt-1 text-xs text-slate-400">
            Images, PDF, Word, text &amp; source code{config ? ` · up to ${formatBytes(config.maxFileBytes)} each` : ''}
          </p>
        </div>
        <button className="btn-primary" onClick={() => inputRef.current?.click()}>Browse Files</button>
        <input ref={inputRef} type="file" multiple hidden onChange={(e) => handleFiles(e.target.files)}
          accept={config ? config.allowedExtensions.map((e) => `.${e}`).join(',') : undefined} />
      </div>

      {items.length > 0 && (
        <ul className="mt-3 space-y-2">
          {items.map((i) => (
            <li key={i.id} className="card p-3">
              <div className="flex items-center gap-3">
                {i.status === 'error' ? <AlertCircle className="h-4 w-4 shrink-0 text-rose-400" /> : <Loader2 className={`h-4 w-4 shrink-0 text-indigo-300 ${i.status === 'uploading' ? 'animate-spin' : 'opacity-40'}`} />}
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-medium">{i.name}</p>
                  <p className={`text-xs ${i.status === 'error' ? 'text-rose-300' : 'text-slate-400'}`}>
                    {i.status === 'error' ? i.error : i.status === 'queued' ? `Waiting… · ${formatBytes(i.size)}` : `Uploading ${i.progress}% · ${formatBytes(i.size)}`}
                  </p>
                </div>
                <button className="icon-btn" onClick={() => (i.status === 'error' ? drop(i.id) : cancel(i))} aria-label={i.status === 'error' ? 'Dismiss' : 'Cancel upload'}><X className="h-4 w-4" /></button>
              </div>
              {i.status !== 'error' && (
                <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-white/10"
                  role="progressbar" aria-valuenow={i.progress} aria-valuemin={0} aria-valuemax={100}>
                  <div className="h-full rounded-full bg-gradient-to-r from-indigo-500 to-cyan-400 transition-all" style={{ width: `${i.progress}%` }} />
                </div>
              )}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
