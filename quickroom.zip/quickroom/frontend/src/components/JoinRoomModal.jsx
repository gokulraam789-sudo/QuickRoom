import { useEffect, useState } from 'react';
import { Loader2 } from 'lucide-react';
import Modal from './Modal';
import { api } from '../services/api';
import { formatRoomId, normalizeRoomId } from '../utils/format';

export default function JoinRoomModal({ open, onClose, onJoined, initialRoomId = '' }) {
  const [roomId, setRoomId] = useState('');
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => { if (open) { setRoomId(normalizeRoomId(initialRoomId)); setPassword(''); setError(''); } }, [open, initialRoomId]);

  const submit = async (e) => {
    e.preventDefault();
    setError('');
    if (roomId.length !== 12) return setError('A Room ID has 12 letters and numbers.');
    if (!password) return setError('Enter the room password.');
    setBusy(true);
    try {
      await api.joinRoom(roomId, password);
      onJoined();
    } catch (err) {
      setError(err.status === 410 ? 'That room has expired.' : err.message);
    } finally { setBusy(false); }
  };

  return (
    <Modal open={open} onClose={onClose} title="Join a room">
      <form onSubmit={submit} className="space-y-5">
        <div>
          <label className="label" htmlFor="jr-id">Room ID</label>
          <input id="jr-id" className="input font-mono tracking-widest" value={formatRoomId(roomId)} placeholder="XXXX-XXXX-XXXX"
            onChange={(e) => setRoomId(normalizeRoomId(e.target.value))} autoCapitalize="characters" autoComplete="off" spellCheck={false} />
        </div>
        <div>
          <label className="label" htmlFor="jr-pass">Password</label>
          <input id="jr-pass" className="input" type="password" value={password} onChange={(e) => setPassword(e.target.value)} autoComplete="off" maxLength={72} />
        </div>
        {error && <p className="rounded-lg bg-rose-500/10 px-3 py-2 text-sm text-rose-300" role="alert">{error}</p>}
        <button className="btn-primary w-full" disabled={busy}>{busy && <Loader2 className="h-4 w-4 animate-spin" />} Join Room</button>
      </form>
    </Modal>
  );
}
