import { Zap } from 'lucide-react';

export default function Logo({ size = 'md' }) {
  const box = size === 'lg' ? 'h-11 w-11' : 'h-9 w-9';
  return (
    <div className="flex items-center gap-2.5">
      <div className={`${box} flex items-center justify-center rounded-xl bg-gradient-to-br from-indigo-500 to-cyan-500 shadow-lg shadow-indigo-500/30`}>
        <Zap className="h-5 w-5 text-white" />
      </div>
      <span className="text-lg font-bold tracking-tight">Quick<span className="text-cyan-300">Room</span></span>
    </div>
  );
}
