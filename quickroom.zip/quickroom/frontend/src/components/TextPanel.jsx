import { useState } from 'react';
import { Loader2, MessageSquareText, Send } from 'lucide-react';
import NoteCard from './NoteCard';
import { api } from '../services/api';

export default function TextPanel({ notes, meId, config, actions, toast }) {
  const [text, setText] = useState('');
  const [busy, setBusy] = useState(false);
  const items = notes.filter((n) => n.kind === 'text');
  const max = config?.maxTextChars ?? 20000;

  const share = async () => {
    if (!text.trim() || busy) return;
    setBusy(true);
    try { const { note } = await api.createNote({ kind: 'text', content: text }); actions.addNote(note); setText(''); }
    catch (e) { toast(e.message, 'error'); } finally { setBusy(false); }
  };
  const remove = async (note) => {
    try { await api.deleteNote(note.id); actions.removeNote(note.id); } catch (e) { toast(e.message, 'error'); }
  };

  return (
    <div className="space-y-4">
      <div className="card p-3.5">
        <textarea className="input min-h-[110px] resize-y" placeholder="Type or paste text to share — links, notes, a snippet of an email…"
          value={text} maxLength={max} onChange={(e) => setText(e.target.value)}
          onKeyDown={(e) => { if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') share(); }} aria-label="Text to share" />
        <div className="mt-2.5 flex items-center justify-between">
          <span className="text-xs text-slate-500">{text.length.toLocaleString()} / {max.toLocaleString()} · Ctrl+Enter to share</span>
          <button className="btn-primary" onClick={share} disabled={!text.trim() || busy}>
            {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />} Share Text
          </button>
        </div>
      </div>
      {items.length === 0 ? (
        <div className="card px-6 py-10 text-center">
          <MessageSquareText className="mx-auto h-8 w-8 text-slate-600" />
          <p className="mt-3 text-sm font-medium text-slate-300">Nothing shared yet</p>
          <p className="mt-1 text-xs text-slate-500">Shared text shows up on every device here, then vanishes with the room.</p>
        </div>
      ) : (
        <ul className="space-y-3">{items.map((n) => <NoteCard key={n.id} note={n} mine={n.ownerId === meId} onDelete={remove} />)}</ul>
      )}
    </div>
  );
}
