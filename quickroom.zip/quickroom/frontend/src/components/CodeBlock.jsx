import hljs from 'highlight.js/lib/core';
import python from 'highlight.js/lib/languages/python';
import javascript from 'highlight.js/lib/languages/javascript';
import typescript from 'highlight.js/lib/languages/typescript';
import java from 'highlight.js/lib/languages/java';
import c from 'highlight.js/lib/languages/c';
import cpp from 'highlight.js/lib/languages/cpp';
import xml from 'highlight.js/lib/languages/xml';
import css from 'highlight.js/lib/languages/css';
import sql from 'highlight.js/lib/languages/sql';
import json from 'highlight.js/lib/languages/json';
import 'highlight.js/styles/github-dark.css';

Object.entries({ python, javascript, typescript, java, c, cpp, xml, css, sql, json }).forEach(([n, l]) => hljs.registerLanguage(n, l));

export const LANGUAGES = [
  ['python', 'Python'], ['javascript', 'JavaScript'], ['typescript', 'TypeScript'], ['java', 'Java'], ['c', 'C'], ['cpp', 'C++'],
  ['html', 'HTML'], ['css', 'CSS'], ['sql', 'SQL'], ['json', 'JSON'], ['plaintext', 'Plain text'],
];
export const EXT_LANG = { py: 'python', js: 'javascript', jsx: 'javascript', ts: 'typescript', tsx: 'typescript', java: 'java', c: 'c', h: 'c', cpp: 'cpp', html: 'html', css: 'css', sql: 'sql', json: 'json' };

// highlight.js escapes the source before wrapping tokens in <span>, so the output contains no user-supplied HTML.
export default function CodeBlock({ code, language = 'plaintext', className = '' }) {
  let html = null;
  if (language !== 'plaintext') {
    try { html = hljs.highlight(code, { language: language === 'html' ? 'xml' : language, ignoreIllegals: true }).value; } catch { html = null; }
  }
  return (
    <pre className={`overflow-auto rounded-xl border border-white/10 bg-[#0d1117] p-3.5 font-mono text-[13px] leading-relaxed ${className}`}>
      {html !== null ? <code className="hljs" dangerouslySetInnerHTML={{ __html: html }} /> : <code>{code}</code>}
    </pre>
  );
}
