import { useState } from 'react';
import { Check, Copy } from 'lucide-react';
import { copyText } from '../utils/format';

export default function CopyButton({ text, label, className = 'icon-btn', title = 'Copy' }) {
  const [done, setDone] = useState(false);
  const onClick = async () => {
    if (await copyText(text)) { setDone(true); setTimeout(() => setDone(false), 1500); }
  };
  return (
    <button type="button" onClick={onClick} className={className} title={title} aria-label={title}>
      {done ? <Check className="h-4 w-4 text-emerald-400" /> : <Copy className="h-4 w-4" />}
      {label && <span>{done ? 'Copied' : label}</span>}
    </button>
  );
}
