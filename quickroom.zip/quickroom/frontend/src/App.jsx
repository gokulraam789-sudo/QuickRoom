import { useEffect, useState } from 'react';
import LandingPage from './pages/LandingPage';
import RoomPage from './pages/RoomPage';
import ExpiredPage from './pages/ExpiredPage';
import CreateRoomModal from './components/CreateRoomModal';
import JoinRoomModal from './components/JoinRoomModal';
import { sessionStore } from './services/api';

export default function App() {
  const [view, setView] = useState(() => (sessionStore.get() ? 'room' : 'home'));
  const [modal, setModal] = useState(null); // 'create' | 'join' | null
  const [creds, setCreds] = useState(null); // creator's room id + password, kept in memory only
  const [joinId, setJoinId] = useState('');
  const [expired, setExpired] = useState({ cleanupConfirmed: null });

  // Invite links look like https://site/?room=ABCDEFGHJKLM and only pre-fill the Room ID (never the password).
  useEffect(() => {
    const id = new URLSearchParams(window.location.search).get('room');
    if (id) { setJoinId(id); setModal('join'); window.history.replaceState({}, '', window.location.pathname); }
  }, []);

  const goHome = () => { sessionStore.clear(); setCreds(null); setView('home'); };
  const enterCreated = (c) => { setCreds(c); setModal(null); setView('room'); };
  const expire = (info) => { setCreds(null); setExpired(info); setView('expired'); };

  if (view === 'room') return <RoomPage creds={creds} onLeave={goHome} onExpired={expire} />;
  if (view === 'expired') return <ExpiredPage cleanupConfirmed={expired.cleanupConfirmed} onHome={goHome} onCreate={() => { goHome(); setModal('create'); }} />;
  return (
    <>
      <LandingPage onCreate={() => setModal('create')} onJoin={() => { setJoinId(''); setModal('join'); }} />
      <CreateRoomModal open={modal === 'create'} onClose={() => setModal(null)} onEnter={enterCreated} />
      <JoinRoomModal open={modal === 'join'} onClose={() => setModal(null)} initialRoomId={joinId} onJoined={() => { setModal(null); setCreds(null); setView('room'); }} />
    </>
  );
}
