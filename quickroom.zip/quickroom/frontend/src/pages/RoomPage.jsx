import { useEffect, useState } from 'react';
import { Code2, Files, Loader2, MessageSquareText } from 'lucide-react';
import RoomHeader from '../components/RoomHeader';
import UploadZone from '../components/UploadZone';
import FileList from '../components/FileList';
import FilePreview from '../components/FilePreview';
import TextPanel from '../components/TextPanel';
import CodePanel from '../components/CodePanel';
import Toasts from '../components/Toasts';
import Modal from '../components/Modal';
import CopyButton from '../components/CopyButton';
import { api, sessionStore } from '../services/api';
import { useRoom } from '../hooks/useRoom';
import { useCountdown } from '../hooks/useCountdown';
import { useToasts } from '../hooks/useToasts';
import { formatRoomId } from '../utils/format';

export default function RoomPage({ creds, onLeave, onExpired }) {
  const { data, participants, connected, offset, error, refresh, actions } = useRoom({ onExpired, onLost: () => onLeave() });
  const ms = useCountdown(data?.room.expiresAt, offset);
  const [tab, setTab] = useState('files');
  const [selectedId, setSelectedId] = useState(null);
  const [config, setConfig] = useState(null);
  const [invite, setInvite] = useState(false);
  const [toasts, toast] = useToasts();

  useEffect(() => { api.config().then(setConfig).catch(() => {}); }, []);

  // The countdown is cosmetic. At zero we just ask the server what really happened.
  useEffect(() => {
    if (ms !== 0) return undefined;
    refresh();
    const t = setInterval(refresh, 2000);
    return () => clearInterval(t);
  }, [ms, refresh]);

  if (!data) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center gap-3 text-slate-300">
        {error ? (<><p>{error}</p><button className="btn-ghost" onClick={refresh}>Try again</button></>) : <Loader2 className="h-6 w-6 animate-spin text-indigo-300" />}
      </div>
    );
  }

  const meId = data.me.participantId;
  const selected = data.files.find((f) => f.id === selectedId);

  const leave = async () => { await api.leave(); sessionStore.clear(); onLeave(); };

  const download = async (file) => {
    try {
      const { blob } = await api.fetchFile(file.id, 'download');
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url; a.download = file.name; document.body.appendChild(a); a.click(); a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 10_000);
    } catch (e) { toast(e.status === 0 ? 'Download failed — check your connection and try again.' : e.message, 'error'); }
  };
  const removeFile = async (file) => {
    try { await api.deleteFile(file.id); actions.removeFile(file.id); if (selectedId === file.id) setSelectedId(null); }
    catch (e) { toast(e.message, 'error'); }
  };

  const tabs = [
    { id: 'files', label: 'Files', Icon: Files, count: data.files.length },
    { id: 'text', label: 'Text', Icon: MessageSquareText, count: data.notes.filter((n) => n.kind === 'text').length },
    { id: 'code', label: 'Code', Icon: Code2, count: data.notes.filter((n) => n.kind === 'code').length },
  ];

  return (
    <div className="min-h-screen">
      <RoomHeader roomId={data.room.id} ms={ms} connected={connected} participants={participants}
        onLeave={leave} onInvite={creds ? () => setInvite(true) : undefined} />
      <main className="mx-auto max-w-6xl px-4 py-5">
        <div className="mb-5 flex gap-1 rounded-xl border border-white/10 bg-white/[0.03] p-1" role="tablist">
          {tabs.map(({ id, label, Icon, count }) => (
            <button key={id} role="tab" aria-selected={tab === id} onClick={() => setTab(id)}
              className={`flex flex-1 items-center justify-center gap-2 rounded-lg px-3 py-2 text-sm font-medium transition ${tab === id ? 'bg-indigo-500/25 text-white' : 'text-slate-400 hover:text-slate-200'}`}>
              <Icon className="h-4 w-4" /> {label}
              {count > 0 && <span className="rounded-full bg-white/10 px-1.5 text-xs">{count}</span>}
            </button>
          ))}
        </div>

        {tab === 'files' && (
          <div className="grid gap-5 lg:grid-cols-2">
            <div className="space-y-5">
              <UploadZone config={config} toast={toast} onUploaded={actions.addFile} />
              <FileList files={data.files} meId={meId} selectedId={selectedId} onSelect={setSelectedId} onDownload={download} onDelete={removeFile} />
            </div>
            <div>
              {selected ? <FilePreview file={selected} onClose={() => setSelectedId(null)} /> : (
                <div className="card flex h-full min-h-[200px] flex-col items-center justify-center px-6 py-10 text-center">
                  <p className="text-sm font-medium text-slate-300">File preview</p>
                  <p className="mt-1 text-xs text-slate-500">Select the eye icon on an image, PDF, text or code file to preview it here.</p>
                </div>
              )}
            </div>
          </div>
        )}
        {tab === 'text' && <div className="mx-auto max-w-2xl"><TextPanel notes={data.notes} meId={meId} config={config} actions={actions} toast={toast} /></div>}
        {tab === 'code' && <div className="mx-auto max-w-3xl"><CodePanel notes={data.notes} meId={meId} config={config} actions={actions} toast={toast} /></div>}
      </main>

      <Modal open={invite} onClose={() => setInvite(false)} title="Invite someone">
        {creds && (
          <div className="space-y-3 text-sm">
            <Row label="Room ID" value={formatRoomId(data.room.id)} copy={data.room.id} />
            <Row label="Password" value={creds.password} copy={creds.password} />
            <CopyButton className="btn-ghost w-full" label="Copy invite message" title="Copy invite"
              text={`Join my QuickRoom\nRoom ID: ${formatRoomId(data.room.id)}\nPassword: ${creds.password}\n${window.location.origin}`} />
          </div>
        )}
      </Modal>
      <Toasts list={toasts} />
    </div>
  );
}

function Row({ label, value, copy }) {
  return (
    <div>
      <span className="label">{label}</span>
      <div className="flex items-center justify-between gap-2 rounded-xl border border-white/10 bg-slate-950 px-3.5 py-2.5">
        <code className="break-all font-mono text-cyan-200">{value}</code>
        <CopyButton text={copy} title={`Copy ${label}`} />
      </div>
    </div>
  );
}
