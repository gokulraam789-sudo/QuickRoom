import { motion } from 'framer-motion';
import { Clock, FileCode, FileImage, FileText, Laptop, LogIn, Plus, ShieldCheck, Smartphone, Trash2, UserX } from 'lucide-react';
import Logo from '../components/Logo';

function TransferVisual() {
  const chips = [
    { Icon: FileImage, label: 'photo.png', top: '18%', delay: 0 },
    { Icon: FileText, label: 'report.pdf', top: '45%', delay: 1 },
    { Icon: FileCode, label: 'main.py', top: '72%', delay: 2 },
  ];
  return (
    <div className="relative mx-auto flex h-72 w-full max-w-lg items-center justify-between gap-2 px-2" aria-hidden="true">
      <div className="absolute inset-x-8 top-1/2 h-40 -translate-y-1/2 rounded-full bg-gradient-to-r from-indigo-500/20 to-cyan-500/20 blur-3xl" />
      <motion.div animate={{ y: [0, -6, 0] }} transition={{ duration: 5, repeat: Infinity }} className="relative z-10 flex flex-col items-center">
        <div className="flex h-28 w-44 items-center justify-center rounded-t-xl border border-white/15 bg-slate-900 shadow-xl">
          <Laptop className="h-10 w-10 text-indigo-300" />
        </div>
        <div className="h-2.5 w-52 rounded-b-xl bg-slate-700" />
        <span className="mt-3 text-xs text-slate-400">College computer</span>
      </motion.div>
      <div className="relative z-0 h-full flex-1">
        {chips.map(({ Icon, label, top, delay }) => (
          <motion.div key={label} className="absolute flex items-center gap-1.5 rounded-lg border border-white/15 bg-slate-800/90 px-2 py-1 text-[11px] text-slate-200 shadow-lg"
            style={{ top }} initial={{ left: '-10%', opacity: 0 }}
            animate={{ left: ['-10%', '40%'], opacity: [0, 1, 1, 0] }} transition={{ duration: 3.2, repeat: Infinity, delay, ease: 'easeInOut' }}>
            <Icon className="h-3.5 w-3.5 text-cyan-300" /> {label}
          </motion.div>
        ))}
      </div>
      <motion.div animate={{ y: [0, 6, 0] }} transition={{ duration: 5, repeat: Infinity }} className="relative z-10 flex flex-col items-center">
        <div className="flex h-40 w-[5.5rem] items-center justify-center rounded-[1.6rem] border-2 border-white/20 bg-slate-900 shadow-xl">
          <Smartphone className="h-8 w-8 text-cyan-300" />
        </div>
        <span className="mt-3 text-xs text-slate-400">Your phone</span>
      </motion.div>
    </div>
  );
}

const FEATURES = [
  { Icon: UserX, title: 'No accounts', text: 'No sign-up, no email, no login. Open the site, make a room, share the ID and password.' },
  { Icon: Clock, title: 'Up to 30 minutes', text: 'Every room has a hard time limit set by the server. It can never be extended.' },
  { Icon: Trash2, title: 'Auto cleanup', text: 'When the timer ends the room is locked and its files and messages are deleted.' },
];

export default function LandingPage({ onCreate, onJoin }) {
  return (
    <div className="bg-grid min-h-screen">
      <nav className="mx-auto flex max-w-6xl items-center justify-between px-4 py-5">
        <Logo />
        <button className="btn-ghost !py-2" onClick={onJoin}>Join Room</button>
      </nav>

      <main className="mx-auto max-w-6xl px-4 pb-16">
        <section className="grid items-center gap-10 pb-16 pt-8 lg:grid-cols-2 lg:pt-16">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
            <span className="inline-flex items-center gap-1.5 rounded-full border border-cyan-400/30 bg-cyan-400/10 px-3 py-1 text-xs font-medium text-cyan-200">
              <Clock className="h-3.5 w-3.5" /> Rooms last up to 30 minutes
            </span>
            <h1 className="mt-5 text-4xl font-extrabold leading-tight tracking-tight sm:text-5xl lg:text-6xl">
              Share Anything.{' '}
              <span className="bg-gradient-to-r from-indigo-400 to-cyan-300 bg-clip-text text-transparent">Leave Nothing Behind.</span>
            </h1>
            <p className="mt-5 max-w-xl text-lg text-slate-300">
              Move files, text and code between college computers, laptops and phones — without logging in or carrying a USB drive.
              Create a temporary room, share the ID and password, and everything is wiped when time runs out.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <button className="btn-primary !px-6 !py-3 !text-base" onClick={onCreate}><Plus className="h-5 w-5" /> Create Room</button>
              <button className="btn-ghost !px-6 !py-3 !text-base" onClick={onJoin}><LogIn className="h-5 w-5" /> Join Room</button>
            </div>
            <p className="mt-5 flex items-start gap-2 text-sm text-slate-400">
              <ShieldCheck className="mt-0.5 h-4 w-4 shrink-0 text-emerald-400" />
              <span>Files are stored on our server only temporarily and deleted automatically when the room expires. Don’t share anything highly sensitive — transfers are protected by HTTPS and a room password, but are not end-to-end encrypted.</span>
            </p>
          </motion.div>
          <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: 0.6, delay: 0.1 }}>
            <TransferVisual />
          </motion.div>
        </section>

        <section className="grid gap-4 sm:grid-cols-3">
          {FEATURES.map(({ Icon, title, text }) => (
            <div key={title} className="card p-5">
              <div className="mb-3 flex h-10 w-10 items-center justify-center rounded-xl bg-indigo-500/15 text-indigo-300"><Icon className="h-5 w-5" /></div>
              <h3 className="font-semibold">{title}</h3>
              <p className="mt-1.5 text-sm text-slate-400">{text}</p>
            </div>
          ))}
        </section>
      </main>
      <footer className="border-t border-white/5 py-6 text-center text-xs text-slate-500">QuickRoom · Share Anything. Leave Nothing Behind.</footer>
    </div>
  );
}
