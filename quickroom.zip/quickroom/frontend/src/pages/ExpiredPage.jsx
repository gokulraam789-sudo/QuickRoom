import { motion } from 'framer-motion';
import { Lock, Timer } from 'lucide-react';
import Logo from '../components/Logo';

export default function ExpiredPage({ cleanupConfirmed, onCreate, onHome }) {
  // Only claim deletion when the server has confirmed it.
  const note = cleanupConfirmed === true
    ? 'Its files and shared items have been deleted from the server.'
    : cleanupConfirmed === false
      ? 'The room is locked. Deleting its temporary files is still in progress and will keep being retried automatically.'
      : '';
  return (
    <div className="bg-grid flex min-h-screen flex-col items-center justify-center px-4 text-center">
      <div className="absolute left-4 top-5"><Logo /></div>
      <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} className="relative mb-8 flex h-32 w-32 items-center justify-center rounded-full border border-white/10 bg-gradient-to-br from-indigo-500/20 to-cyan-500/20">
        <Timer className="h-16 w-16 text-slate-400" />
        <div className="absolute -bottom-1 -right-1 flex h-12 w-12 items-center justify-center rounded-full bg-rose-500 shadow-lg shadow-rose-500/40"><Lock className="h-6 w-6 text-white" /></div>
      </motion.div>
      <h1 className="text-4xl font-extrabold tracking-tight">Room Expired</h1>
      <p className="mt-3 text-lg text-slate-300">This room is no longer available.</p>
      {note && <p className="mt-2 max-w-md text-sm text-slate-400">{note}</p>}
      <div className="mt-8 flex flex-wrap justify-center gap-3">
        <button className="btn-primary" onClick={onCreate}>Create New Room</button>
        <button className="btn-ghost" onClick={onHome}>Back to Home</button>
      </div>
    </div>
  );
}
