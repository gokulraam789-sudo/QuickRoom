import { useEffect, useState } from 'react';

// Display only. `offset` = serverTime - clientTime so a wrong device clock doesn't matter.
export function useCountdown(expiresAt, offset) {
  const calc = () => (expiresAt ? Math.max(0, expiresAt - (Date.now() + offset)) : null);
  const [ms, setMs] = useState(calc);
  useEffect(() => {
    setMs(calc());
    const t = setInterval(() => setMs(calc()), 1000);
    return () => clearInterval(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [expiresAt, offset]);
  return ms;
}
