import { useCallback, useEffect, useRef, useState } from 'react';
import { api, sessionStore } from '../services/api';
import { connectSocket } from '../services/socket';

// Loads room state over HTTP and keeps it live over Socket.IO.
// Every event is de-duplicated by id, so reconnects and our own uploads never create duplicates.
export function useRoom({ onExpired, onLost }) {
  const [data, setData] = useState(null);
  const [participants, setParticipants] = useState(1);
  const [connected, setConnected] = useState(false);
  const [offset, setOffset] = useState(0);
  const [error, setError] = useState(null);
  const cb = useRef({ onExpired, onLost });
  cb.current = { onExpired, onLost };

  const refresh = useCallback(async () => {
    try {
      const d = await api.getState();
      setOffset(d.serverTime - Date.now());
      setParticipants((p) => Math.max(1, d.participants || p));
      setData({ room: d.room, files: d.files, notes: d.notes, me: d.me });
      setError(null);
    } catch (e) {
      if (e.status === 410) { sessionStore.clear(); cb.current.onExpired({ cleanupConfirmed: e.extra?.cleanupConfirmed ?? null }); }
      else if (e.status === 401 || e.status === 404) { sessionStore.clear(); cb.current.onLost(); }
      else setError(e.message);
    }
  }, []);

  useEffect(() => {
    refresh();
    const socket = connectSocket();
    let first = true;
    socket.on('connect', () => { setConnected(true); if (first) first = false; else refresh(); }); // resync after a reconnect
    socket.on('disconnect', () => setConnected(false));
    socket.on('connect_error', (err) => { if (err.message === 'UNAUTHORIZED' || err.message === 'ROOM_EXPIRED') refresh(); });
    socket.on('participants', ({ count }) => setParticipants(Math.max(1, count)));
    socket.on('file:added', ({ file }) => setData((d) => (d && !d.files.some((f) => f.id === file.id) ? { ...d, files: [...d.files, file] } : d)));
    socket.on('file:removed', ({ id }) => setData((d) => d && { ...d, files: d.files.filter((f) => f.id !== id) }));
    socket.on('note:added', ({ note }) => setData((d) => (d && !d.notes.some((n) => n.id === note.id) ? { ...d, notes: [note, ...d.notes] } : d)));
    socket.on('note:removed', ({ id }) => setData((d) => d && { ...d, notes: d.notes.filter((n) => n.id !== id) }));
    socket.on('room:expired', ({ cleanupConfirmed }) => { sessionStore.clear(); cb.current.onExpired({ cleanupConfirmed }); });
    return () => socket.close();
  }, [refresh]);

  // Local helpers so the sender sees changes instantly (the socket event is then ignored as a duplicate).
  const actions = {
    addFile: (file) => setData((d) => (d && !d.files.some((f) => f.id === file.id) ? { ...d, files: [...d.files, file] } : d)),
    removeFile: (id) => setData((d) => d && { ...d, files: d.files.filter((f) => f.id !== id) }),
    addNote: (note) => setData((d) => (d && !d.notes.some((n) => n.id === note.id) ? { ...d, notes: [note, ...d.notes] } : d)),
    removeNote: (id) => setData((d) => d && { ...d, notes: d.notes.filter((n) => n.id !== id) }),
  };
  return { data, participants, connected, offset, error, refresh, actions };
}
