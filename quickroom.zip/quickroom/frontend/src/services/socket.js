import { io } from 'socket.io-client';
import { sessionStore } from './api';

// The token is read again on every (re)connect, so reconnects always use the current session.
export function connectSocket() {
  return io(import.meta.env.VITE_API_URL || undefined, {
    auth: (cb) => cb({ token: sessionStore.get()?.token || '' }),
    reconnectionDelayMax: 5000,
  });
}
