const BASE = import.meta.env.VITE_API_URL || '';
const KEY = 'quickroom.session';

// The short-lived room access token lives in sessionStorage (per tab, gone when the tab closes).
// It is NOT file content and NOT the password; the server decides if it is still valid.
export const sessionStore = {
  get() { try { return JSON.parse(sessionStorage.getItem(KEY)); } catch { return null; } },
  set(v) { sessionStorage.setItem(KEY, JSON.stringify(v)); },
  clear() { sessionStorage.removeItem(KEY); },
};

export class ApiError extends Error {
  constructor(status, code, message, extra = {}) { super(message); this.status = status; this.code = code; this.extra = extra; }
}

const authHeader = () => { const s = sessionStore.get(); return s?.token ? { Authorization: `Bearer ${s.token}` } : {}; };
const NETWORK = () => new ApiError(0, 'NETWORK', 'Can’t reach the server. Check your connection and try again.');

async function toError(res) {
  let e = null;
  try { e = (await res.json()).error; } catch { /* not json */ }
  return new ApiError(res.status, e?.code || 'ERROR', e?.message || 'Something went wrong. Please try again.', e || {});
}

async function request(path, { method = 'GET', body } = {}) {
  let res;
  try {
    res = await fetch(BASE + path, {
      method,
      headers: { ...(body ? { 'Content-Type': 'application/json' } : {}), ...authHeader() },
      body: body ? JSON.stringify(body) : undefined,
    });
  } catch { throw NETWORK(); }
  if (!res.ok) throw await toError(res);
  return res.json();
}

const saveSession = (d) => { sessionStore.set({ token: d.token, roomId: d.roomId, participantId: d.participantId }); return d; };

export const api = {
  config: () => request('/api/config'),
  createRoom: (durationMinutes, password) => request('/api/rooms', { method: 'POST', body: { durationMinutes, password } }).then(saveSession),
  joinRoom: (roomId, password) => request('/api/rooms/join', { method: 'POST', body: { roomId, password } }).then(saveSession),
  getState: () => request('/api/rooms/state'),
  leave: () => request('/api/rooms/leave', { method: 'POST' }).catch(() => {}),
  createNote: (note) => request('/api/rooms/notes', { method: 'POST', body: note }),
  deleteNote: (id) => request(`/api/rooms/notes/${id}`, { method: 'DELETE' }),
  deleteFile: (id) => request(`/api/rooms/files/${id}`, { method: 'DELETE' }),

  // Files require the Authorization header, so we fetch them as blobs instead of linking to a public URL.
  async fetchFile(id, mode) {
    let res;
    try { res = await fetch(`${BASE}/api/rooms/files/${id}/${mode}`, { headers: authHeader() }); } catch { throw NETWORK(); }
    if (!res.ok) throw await toError(res);
    return { blob: await res.blob(), truncated: res.headers.get('X-Preview-Truncated') === 'true' };
  },

  // XHR (not fetch) because it reports upload progress.
  uploadFile(file, onProgress) {
    const xhr = new XMLHttpRequest();
    const promise = new Promise((resolve, reject) => {
      xhr.open('POST', `${BASE}/api/rooms/files`);
      const h = authHeader();
      if (h.Authorization) xhr.setRequestHeader('Authorization', h.Authorization);
      xhr.upload.onprogress = (e) => { if (e.lengthComputable) onProgress(Math.round((e.loaded / e.total) * 100)); };
      xhr.onload = () => {
        let data = null;
        try { data = JSON.parse(xhr.responseText); } catch { /* ignore */ }
        if (xhr.status >= 200 && xhr.status < 300) resolve(data.file);
        else reject(new ApiError(xhr.status, data?.error?.code || 'ERROR', data?.error?.message || 'Upload failed.', data?.error || {}));
      };
      xhr.onerror = () => reject(new ApiError(0, 'NETWORK', 'Upload interrupted. Check your connection and try again.'));
      xhr.onabort = () => reject(new ApiError(0, 'ABORTED', 'Upload cancelled.'));
      const form = new FormData();
      form.append('file', file);
      xhr.send(form);
    });
    return { promise, abort: () => xhr.abort() };
  },
};
