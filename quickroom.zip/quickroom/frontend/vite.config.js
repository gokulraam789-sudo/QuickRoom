import { defineConfig, loadEnv } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, process.cwd(), '');
  const target = env.VITE_BACKEND_URL || 'http://localhost:4000';
  // The browser only talks to the Vite origin; Vite forwards API + websocket traffic to the backend.
  // That means in GitHub Codespaces you only need port 5173 and no CORS setup.
  const proxy = { '/api': { target }, '/socket.io': { target, ws: true } };
  return {
    plugins: [react()],
    server: { host: true, port: 5173, allowedHosts: true, proxy },
    preview: { host: true, port: 5173, allowedHosts: true, proxy },
  };
});
